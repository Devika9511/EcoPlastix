
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useEffect } from "react";

// Landing and Auth Pages
import Index from "./pages/Index";
import Login from "./pages/auth/Login";
import AdminLogin from "./pages/auth/AdminLogin";
import Signup from "./pages/auth/Signup";
import NotFound from "./pages/NotFound";
import PrinciplesPage from "./pages/PrinciplesPage";
import ContactPage from "./pages/ContactPage";
import AboutPage from "./pages/AboutPage";

// Dashboard Pages
import UserDashboard from "./pages/dashboards/UserDashboard";
import CompanyDashboard from "./pages/dashboards/CompanyDashboard";
import AdminDashboard from "./pages/dashboards/AdminDashboard";

// User Specific Pages
import UploadPlastic from "./pages/user/UploadPlastic";
import UserProfile from "./pages/user/UserProfile";
import MyUploads from "./pages/user/MyUploads";
import Rewards from "./pages/user/Rewards";

// Company Specific Pages
import AvailablePlastics from "./pages/company/AvailablePlastics";
import CompanyProfile from "./pages/company/CompanyProfile";
import MyOrders from "./pages/company/MyOrders";

// Admin Specific Pages
import ManageUsers from "./pages/admin/ManageUsers";
import ManageCompanies from "./pages/admin/ManageCompanies";
import ReviewUploads from "./pages/admin/ReviewUploads";

const queryClient = new QueryClient();

const AppWithDataCleanup = () => {
  useEffect(() => {
    // We'll let the individual page components handle their own data
    // This prevents default data from persisting
    console.log("App component mounted - data initialization will be handled by individual components");
    
    // Add global event listeners for user and company activities
    const handleUserActivityGlobal = (event) => {
      console.log("Global user activity detected:", event);
    };
    
    const handleCompanyActivityGlobal = (event) => {
      console.log("Global company activity detected:", event);
    };
    
    // Add global event listeners for user and company activities
    window.addEventListener('plasticUploaded', handleUserActivityGlobal);
    window.addEventListener('bidPlaced', handleCompanyActivityGlobal);
    
    return () => {
      window.removeEventListener('plasticUploaded', handleUserActivityGlobal);
      window.removeEventListener('bidPlaced', handleCompanyActivityGlobal);
    };
    
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/admin" element={<AdminLogin />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/principles" element={<PrinciplesPage />} />
            <Route path="/contact" element={<ContactPage />} />
            
            {/* User Dashboard Routes */}
            <Route path="/user-dashboard" element={<UserDashboard />} />
            <Route path="/user-dashboard/upload" element={<UploadPlastic />} />
            <Route path="/user-dashboard/profile" element={<UserProfile />} />
            <Route path="/user-dashboard/my-uploads" element={<MyUploads />} />
            <Route path="/user-dashboard/rewards" element={<Rewards />} />
            
            {/* Company Dashboard Routes */}
            <Route path="/company-dashboard" element={<CompanyDashboard />} />
            <Route path="/company-dashboard/available-plastics" element={<AvailablePlastics />} />
            <Route path="/company-dashboard/profile" element={<CompanyProfile />} />
            <Route path="/company-dashboard/orders" element={<MyOrders />} />
            <Route path="/company-dashboard/my-orders" element={<MyOrders />} /> {/* Additional route for compatibility */}
            
            {/* Admin Dashboard Routes */}
            <Route path="/admin-dashboard" element={<AdminDashboard />} />
            <Route path="/admin-dashboard/users" element={<ManageUsers />} />
            <Route path="/admin-dashboard/companies" element={<ManageCompanies />} />
            <Route path="/admin-dashboard/uploads" element={<ReviewUploads />} />
            
            {/* 404 Route */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default AppWithDataCleanup;
