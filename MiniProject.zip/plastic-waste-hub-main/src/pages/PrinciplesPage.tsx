
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { RefreshCcwIcon, RecycleIcon, ArrowDownIcon, Leaf } from "lucide-react";
import { Link } from "react-router-dom";

const PrinciplesPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">The 4R Principles</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our approach to plastic waste management is guided by these four crucial principles that help
              us build a more sustainable future.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
            {/* Reuse */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                <RefreshCcwIcon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Reuse</h3>
              <p className="text-gray-600">
                Extending the life of plastic products by using them multiple times before disposal.
              </p>
            </div>
            
            {/* Recycle */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-ecoplastix-green-light/20 flex items-center justify-center mb-4">
                <RecycleIcon className="h-8 w-8 text-ecoplastix-green" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Recycle</h3>
              <p className="text-gray-600">
                Converting plastic waste into new raw materials through collection and processing.
              </p>
            </div>
            
            {/* Recover */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-orange-100 flex items-center justify-center mb-4">
                <ArrowDownIcon className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Recover</h3>
              <p className="text-gray-600">
                Extracting value from plastic waste through energy recovery or chemical conversion.
              </p>
            </div>
            
            {/* Renew */}
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-teal-100 flex items-center justify-center mb-4">
                <Leaf className="h-8 w-8 text-teal-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Renew</h3>
              <p className="text-gray-600">
                Developing and using renewable, bio-based alternatives to traditional plastics.
              </p>
            </div>
          </div>
          
          <div className="mt-16 bg-gray-50 p-8 rounded-lg">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How We Apply These Principles</h2>
            <p className="text-gray-700 mb-6">
              At EcoPlastix, we implement these principles in every aspect of our operation:
            </p>
            
            <div className="space-y-4">
              <div className="flex">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-ecoplastix-green-light flex items-center justify-center">
                  <span className="text-white font-bold">1</span>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Collection Network</h3>
                  <p className="text-gray-600">
                    We've established a robust network of collection points for plastic waste, making it easy for 
                    individuals to contribute to the recycling process.
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-ecoplastix-green flex items-center justify-center">
                  <span className="text-white font-bold">2</span>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Sorting and Processing</h3>
                  <p className="text-gray-600">
                    Our advanced sorting facilities separate different types of plastics to ensure optimal recycling processes 
                    for each material type.
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0 w-10 h-10 rounded-full bg-ecoplastix-green-dark flex items-center justify-center">
                  <span className="text-white font-bold">3</span>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Product Innovation</h3>
                  <p className="text-gray-600">
                    We invest in research and development to create new products from recycled materials, closing the 
                    loop and creating a circular economy.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <section className="bg-gradient-to-r from-ecoplastix-green-light to-ecoplastix-green-dark py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white">Join Our Plastic Management Initiative</h2>
            <p className="mt-4 text-lg text-white/80">
              Whether you're an individual looking to responsibly dispose of plastic waste or a company seeking sustainable materials, 
              EcoPlastix connects you to a greener future.
            </p>
            <div className="mt-8">
              <Link to="/signup">
                <button className="bg-white text-ecoplastix-green-dark px-6 py-2 rounded-md font-medium hover:bg-gray-100 transition-colors">
                  Get Started Today
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default PrinciplesPage;
