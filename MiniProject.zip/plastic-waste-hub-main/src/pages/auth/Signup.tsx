
import AuthForm from "@/components/auth/AuthForm";
import Logo from "@/components/Logo";
import { Leaf } from "lucide-react";

const Signup = () => {
  return (
    <div 
      className="min-h-screen flex items-center justify-end p-4 relative"
      style={{
        backgroundImage: "url('/lovable-uploads/3785c9fa-85d0-4e8a-90f8-b9db954791b1.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat"
      }}
    >
      {/* Reduced overlay opacity to make background brighter */}
      <div className="absolute inset-0 bg-black bg-opacity-10"></div>
      
      <div className="w-full max-w-md flex flex-col items-center relative z-10 mr-8">
        <div className="mb-12 text-center">
          <Logo size="lg" />
          <p className="mt-4 text-white font-medium flex items-center justify-center">
            <Leaf className="h-4 w-4 mr-1 text-ecoplastix-green-light" />
            Join our mission for a cleaner planet
          </p>
        </div>
        {/* Made the form container more transparent */}
        <div className="backdrop-blur-sm bg-white/60 rounded-lg p-1 shadow-lg">
          <AuthForm allowSignup={true} allowRoleSelection={true} />
        </div>
      </div>
    </div>
  );
};

export default Signup;
