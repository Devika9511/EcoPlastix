
import AuthForm from "@/components/auth/AuthForm";
import Logo from "@/components/Logo";
import { Leaf } from "lucide-react";

const AdminLogin = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-ecoplastix-green-light/30 to-ecoplastix-blue-light p-4">
      <div className="w-full max-w-md flex flex-col items-center">
        <div className="mb-8 text-center">
          <Logo size="lg" />
          <p className="mt-2 text-gray-600 font-medium flex items-center justify-center">
            <Leaf className="h-4 w-4 mr-1 text-ecoplastix-green-dark" />
            Admin Portal
          </p>
        </div>
        <AuthForm allowSignup={false} allowRoleSelection={false} defaultRole="admin" />
      </div>
    </div>
  );
};

export default AdminLogin;
