
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { RecycleIcon, Users, Building, Award, RotateCcw, Minus, RefreshCw, Package } from "lucide-react";
import { Link } from "react-router-dom";

const AboutPage = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-ecoplastix-green-light/30 to-ecoplastix-blue-light py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-6">
                About <span className="text-ecoplastix-green-light">Eco</span>
                <span className="text-ecoplastix-green-dark">Plastix</span>
              </h1>
              <p className="text-xl text-gray-700">
                We're on a mission to transform the plastic waste management industry through 
                innovation, collaboration, and sustainable practices.
              </p>
            </div>
          </div>
        </div>
        
        {/* Our Story */}
        <div className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:flex lg:items-center lg:space-x-12">
              <div className="lg:w-1/2">
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
                <p className="text-gray-700 mb-4">
                  EcoPlastix was founded in 2020 by a group of environmental engineers and sustainability experts 
                  who recognized the growing crisis of plastic pollution and saw an opportunity to make a difference.
                </p>
                <p className="text-gray-700 mb-4">
                  What began as a small-scale recycling initiative has grown into a comprehensive platform that connects 
                  individuals with recycling companies, creating a seamless ecosystem for plastic waste management.
                </p>
                <p className="text-gray-700">
                  Today, we're proud to be at the forefront of sustainable practices, helping communities reduce their 
                  plastic footprint while creating economic opportunities for recycling businesses.
                </p>
              </div>
              <div className="mt-10 lg:mt-0 lg:w-1/2">
                <div className="rounded-lg overflow-hidden shadow-lg">
                  <img 
                    src="/lovable-uploads/222d77d2-b97f-4735-b198-dacae9fad23d.png" 
                    alt="Environmental sustainability and plastic recycling" 
                    className="w-full h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4R Principles Section */}
        <div className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900">The 4R Principles</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                Our approach to sustainable plastic management is based on the four fundamental principles that guide environmental responsibility.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mb-4">
                  <Minus className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Reduce</h3>
                <p className="text-gray-600">
                  Minimize plastic consumption by choosing alternatives and reducing unnecessary plastic use in daily life.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <RotateCcw className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Reuse</h3>
                <p className="text-gray-600">
                  Give plastic items a second life by finding creative ways to repurpose them before disposal.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <RecycleIcon className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Recycle</h3>
                <p className="text-gray-600">
                  Process plastic waste through proper recycling channels to create new products and materials.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                  <RefreshCw className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Recover</h3>
                <p className="text-gray-600">
                  Extract energy and value from plastic waste that cannot be recycled through innovative recovery methods.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Our Values */}
        <div className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900">Our Values</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
                These core principles guide everything we do at EcoPlastix, from day-to-day operations to long-term strategy.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <RecycleIcon className="h-8 w-8 text-ecoplastix-green" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Sustainability</h3>
                <p className="text-gray-600">
                  We're committed to environmental stewardship and promoting sustainable practices in everything we do.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Community</h3>
                <p className="text-gray-600">
                  We believe in the power of collective action and building strong relationships with all stakeholders.
                </p>
              </div>
              
              <div className="bg-white p-8 rounded-lg shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-4">
                  <Award className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Excellence</h3>
                <p className="text-gray-600">
                  We strive for excellence in our platform, our service, and our impact on the environment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <section className="bg-gradient-to-r from-ecoplastix-green-light to-ecoplastix-green-dark py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white">Join Our Plastic Management Initiative</h2>
            <p className="mt-4 text-lg text-white/80">
              Whether you're an individual looking to responsibly dispose of plastic waste or a company seeking sustainable materials, 
              EcoPlastix connects you to a greener future.
            </p>
            <div className="mt-8">
              <Link to="/signup">
                <button className="bg-white text-ecoplastix-green-dark px-6 py-2 rounded-md font-medium hover:bg-gray-100 transition-colors">
                  Get Started Today
                </button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default AboutPage;
