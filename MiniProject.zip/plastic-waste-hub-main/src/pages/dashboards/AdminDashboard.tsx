
import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { User, Building, FolderOpen, Image, Loader2, MessageSquare } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { useToast } from "@/components/ui/use-toast";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [recentUploads, setRecentUploads] = useState([]);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalCompanies, setTotalCompanies] = useState(0);
  const [pendingUploads, setPendingUploads] = useState(0);
  const [totalPlasticRecycled, setTotalPlasticRecycled] = useState(0);
  const [adminProfit, setAdminProfit] = useState(0);
  const [userFeedback, setUserFeedback] = useState([]);
  const [companyFeedback, setCompanyFeedback] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = () => {
      setLoading(true);
      try {
        // Get users
        const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
        const users = registeredUsers.filter(u => u.role === 'user').length;
        const companies = registeredUsers.filter(u => u.role === 'company').length;
        setTotalUsers(users);
        setTotalCompanies(companies);
        
        // Get uploads
        const storedUploads = localStorage.getItem('adminUploads');
        if (storedUploads) {
          const uploads = JSON.parse(storedUploads);
          
          // Calculate stats
          const awaitingCollectionUploads = uploads.filter(u => u.status === 'Awaiting Collection' || u.status === 'Pending').length;
          
          let recycledKg = 0;
          let profit = 0;
          uploads.forEach(upload => {
            if (upload.status === 'Completed') {
              const quantity = parseFloat(upload.quantity) || 0;
              const factor = upload.unit === 'kg' ? 1 : upload.unit === 'lb' ? 0.453592 : 0.1;
              recycledKg += quantity * factor;
              
              // Calculate profit (50% of bid amount if available)
              if (upload.acceptedBid) {
                profit += parseFloat(upload.acceptedBid.amount) * 0.5;
              }
            }
          });
          
          setPendingUploads(awaitingCollectionUploads);
          setTotalPlasticRecycled(Math.round(recycledKg * 10) / 10);
          setAdminProfit(Math.round(profit * 100) / 100);
          
          // Sort by date (most recent first) and get pending uploads
          setRecentUploads(
            uploads.filter(u => u.status === 'Awaiting Collection' || u.status === 'Pending')
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .slice(0, 5)
          );
        }
        
        // Get feedback
        const userFeedbackData = JSON.parse(localStorage.getItem('userFeedback') || '[]');
        const companyFeedbackData = JSON.parse(localStorage.getItem('companyFeedback') || '[]');
        setUserFeedback(userFeedbackData);
        setCompanyFeedback(companyFeedbackData);
        
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
    
    // Listen for upload events
    window.addEventListener('plasticUploaded', fetchData);
    window.addEventListener('feedbackSubmitted', fetchData);
    window.addEventListener('transactionUpdated', fetchData);
    
    return () => {
      window.removeEventListener('plasticUploaded', fetchData);
      window.removeEventListener('feedbackSubmitted', fetchData);
      window.removeEventListener('transactionUpdated', fetchData);
    };
  }, []);

  const handleCollect = (uploadId) => {
    const storedUploads = localStorage.getItem('adminUploads');
    if (storedUploads) {
      const uploads = JSON.parse(storedUploads);
      const updatedUploads = uploads.map(upload => {
        if (upload.id === uploadId) {
          return {
            ...upload,
            status: 'Collected',
            collectedDate: new Date().toISOString().split('T')[0]
          };
        }
        return upload;
      });
      
      localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
      
      // Also update user uploads
      const userUploads = JSON.parse(localStorage.getItem('userUploads') || '[]');
      const updatedUserUploads = userUploads.map(upload => {
        if (upload.id === uploadId) {
          return {
            ...upload,
            status: 'Collected',
            collectedDate: new Date().toISOString().split('T')[0]
          };
        }
        return upload;
      });
      
      localStorage.setItem('userUploads', JSON.stringify(updatedUserUploads));
      
      // Make this item available for bidding in company dashboard
      const storedCompanyPlastics = localStorage.getItem('availablePlastics');
      let companyPlastics = storedCompanyPlastics ? JSON.parse(storedCompanyPlastics) : [];
      
      // Find the collected item
      const collectedItem = uploads.find(upload => upload.id === uploadId);
      if (collectedItem) {
        // Check if this plastic is already in the available plastics
        const plasticExists = companyPlastics.some(plastic => plastic.id === uploadId);
        
        if (!plasticExists) {
          companyPlastics.push({
            id: collectedItem.id,
            type: collectedItem.type,
            quantity: `${collectedItem.quantity} ${collectedItem.unit}`,
            location: collectedItem.location,
            user: collectedItem.user || "Anonymous",
            status: 'Available',
            date: collectedItem.date,
            highestBid: 'No bids yet',
            highestBidAmount: 0,
            yourBid: null,
            yourBidAmount: null,
            images: collectedItem.imageUrls || [],
            description: collectedItem.description || ''
          });
          
          localStorage.setItem('availablePlastics', JSON.stringify(companyPlastics));
        }
      }
      
      toast({
        title: "Plastic collected",
        description: "The plastic has been marked as collected and is now available for bidding.",
      });
      
      // Dispatch an event to notify other components of the change
      console.log("Dispatching plasticCollected event from AdminDashboard");
      window.dispatchEvent(new CustomEvent('plasticCollected', { detail: { id: uploadId } }));
      
      // Refresh data
      window.dispatchEvent(new Event('transactionUpdated'));
    }
  };

  return (
    <DashboardLayout title="Admin Dashboard" userType="admin">
      <div className="grid gap-6">
        {/* Welcome Section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Admin Control Panel</CardTitle>
            <CardDescription>
              Manage users, companies, and oversee all plastic waste transactions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button 
                className="flex items-center gap-2 bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                onClick={() => navigate('/admin-dashboard/users')}
              >
                <User className="h-4 w-4" /> Manage Users
              </Button>
              <Button 
                className="flex items-center gap-2 bg-ecoplastix-blue hover:bg-ecoplastix-blue-dark"
                onClick={() => navigate('/admin-dashboard/companies')}
              >
                <Building className="h-4 w-4" /> Manage Companies
              </Button>
              <Button 
                className="flex items-center gap-2" 
                variant="outline"
                onClick={() => navigate('/admin-dashboard/uploads')}
              >
                <FolderOpen className="h-4 w-4" /> Review Uploads
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{totalUsers}</p>
                  <p className="text-sm text-gray-500">Registered users</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Companies</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{totalCompanies}</p>
                  <p className="text-sm text-gray-500">Registered companies</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Pending Collection</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{pendingUploads}</p>
                  <p className="text-sm text-gray-500">Uploads awaiting collection</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Admin Profit</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">₹{adminProfit}</p>
                  <p className="text-sm text-gray-500">50% of total sales</p>
                </>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Recent Uploads */}
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <div>
              <CardTitle>Uploads Requiring Collection</CardTitle>
              <CardDescription>Plastic waste waiting to be collected</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/admin-dashboard/uploads')}>
              View All
            </Button>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              </div>
            ) : recentUploads.length === 0 ? (
              <p className="text-center py-6 text-gray-500">No pending uploads to collect</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentUploads.map(upload => (
                    <TableRow key={upload.id}>
                      <TableCell>{upload.type}</TableCell>
                      <TableCell>{upload.quantity} {upload.unit}</TableCell>
                      <TableCell>{upload.user || 'Anonymous'}</TableCell>
                      <TableCell>
                        <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                          {upload.status === 'Pending' ? 'Awaiting Collection' : upload.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{upload.date}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="flex items-center gap-1">
                                <Image className="h-4 w-4" /> Images
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>{upload.type} Images</DialogTitle>
                                <DialogDescription>
                                  Images of the plastic waste uploaded by {upload.user || 'Anonymous'}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="grid grid-cols-2 gap-4 mt-4">
                                {upload.imageUrls && upload.imageUrls.map((img, idx) => (
                                  <div key={idx} className="border rounded-md overflow-hidden">
                                    <img src={img} alt={`Plastic upload ${idx+1}`} className="w-full h-48 object-cover" />
                                  </div>
                                ))}
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          <Button 
                            size="sm" 
                            className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                            onClick={() => handleCollect(upload.id)}
                          >
                            Mark as Collected
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* User Feedback Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-ecoplastix-blue" />
              User & Company Feedback
            </CardTitle>
            <CardDescription>Recent feedback from users and companies</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-3">User Feedback</h3>
                {userFeedback.length === 0 ? (
                  <p className="text-gray-500 italic">No user feedback available</p>
                ) : (
                  <div className="space-y-4">
                    {userFeedback.slice(0, 3).map((feedback, index) => (
                      <div key={index} className="bg-gray-50 p-3 rounded-md">
                        <div className="flex justify-between mb-1">
                          <p className="font-medium">{feedback.user || 'Anonymous User'}</p>
                          <p className="text-sm text-gray-500">{feedback.date}</p>
                        </div>
                        <p className="text-sm">{feedback.message}</p>
                        {feedback.rating && (
                          <div className="flex items-center mt-2">
                            <span className="text-sm text-gray-600 mr-2">Rating:</span>
                            <div className="flex">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <span key={i} className={`text-lg ${i < feedback.rating ? 'text-yellow-500' : 'text-gray-300'}`}>★</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-3">Company Feedback</h3>
                {companyFeedback.length === 0 ? (
                  <p className="text-gray-500 italic">No company feedback available</p>
                ) : (
                  <div className="space-y-4">
                    {companyFeedback.slice(0, 3).map((feedback, index) => (
                      <div key={index} className="bg-blue-50 p-3 rounded-md">
                        <div className="flex justify-between mb-1">
                          <p className="font-medium">{feedback.company || 'Anonymous Company'}</p>
                          <p className="text-sm text-gray-500">{feedback.date}</p>
                        </div>
                        <p className="text-sm">{feedback.message}</p>
                        {feedback.rating && (
                          <div className="flex items-center mt-2">
                            <span className="text-sm text-gray-600 mr-2">Rating:</span>
                            <div className="flex">
                              {Array.from({ length: 5 }).map((_, i) => (
                                <span key={i} className={`text-lg ${i < feedback.rating ? 'text-yellow-500' : 'text-gray-300'}`}>★</span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default AdminDashboard;
