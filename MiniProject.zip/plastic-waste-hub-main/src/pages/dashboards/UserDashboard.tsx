
import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Upload, FolderOpen, User, Award, Loader2 } from "lucide-react";

const UserDashboard = () => {
  const navigate = useNavigate();
  const [recentUploads, setRecentUploads] = useState([]);
  const [totalUploads, setTotalUploads] = useState(0);
  const [approvedUploads, setApprovedUploads] = useState(0);
  const [totalWeight, setTotalWeight] = useState(0);
  const [approvedWeight, setApprovedWeight] = useState(0);
  const [loading, setLoading] = useState(true);
  const [userPoints, setUserPoints] = useState(0);

  useEffect(() => {
    const fetchData = () => {
      setLoading(true);
      try {
        const storedUploads = localStorage.getItem('userUploads');
        if (storedUploads) {
          const uploads = JSON.parse(storedUploads);
          
          // Calculate stats
          const total = uploads.length;
          const approved = uploads.filter((u) => u.status === 'Approved' || u.status === 'Collected Awaiting Bid' || u.status === 'Bid Accepted' || u.status === 'Sold').length;
          
          let totalKg = 0;
          let approvedKg = 0;
          
          uploads.forEach(upload => {
            const quantity = parseFloat(upload.quantity);
            const factor = upload.unit === 'kg' ? 1 : upload.unit === 'lb' ? 0.453592 : 0.1; // Rough estimate for pieces
            
            totalKg += quantity * factor;
            
            if (upload.status === 'Approved' || upload.status === 'Collected Awaiting Bid' || upload.status === 'Bid Accepted' || upload.status === 'Sold') {
              approvedKg += quantity * factor;
            }
          });
          
          setTotalUploads(total);
          setApprovedUploads(approved);
          setTotalWeight(Math.round(totalKg * 10) / 10);
          setApprovedWeight(Math.round(approvedKg * 10) / 10);
          
          // Sort by date (most recent first) and get first few items
          setRecentUploads(uploads.slice(0, 5));
        }

        // Get user points
        const points = localStorage.getItem('userPoints');
        if (points) {
          setUserPoints(parseInt(points));
        } else {
          setUserPoints(0);
          localStorage.setItem('userPoints', '0');
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
    
    // Listen for upload events
    window.addEventListener('plasticUploaded', fetchData);
    
    return () => {
      window.removeEventListener('plasticUploaded', fetchData);
    };
  }, []);

  // Helper function to get status display text
  const getStatusDisplay = (status) => {
    switch (status) {
      case 'Collection Pending':
        return 'Collection Pending';
      case 'Approved':
        return 'Awaiting Collection';
      case 'Collected Awaiting Bid':
        return 'Available for Bidding';
      case 'Bid Accepted':
        return 'Bid Accepted';
      case 'Sold':
        return 'Sold';
      default:
        return status || 'Collection Pending';
    }
  };

  // Helper function to get status badge class
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Collection Pending':
        return 'bg-orange-100 text-orange-800';
      case 'Approved':
        return 'bg-green-100 text-green-800';
      case 'Collected Awaiting Bid':
        return 'bg-blue-100 text-blue-800';
      case 'Bid Accepted':
        return 'bg-yellow-100 text-yellow-800';
      case 'Sold':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-orange-100 text-orange-800';
    }
  };

  return (
    <DashboardLayout title="User Dashboard" userType="user">
      <div className="grid gap-6">
        {/* Welcome Section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Welcome to EcoPlastix</CardTitle>
            <CardDescription>
              Upload your plastic waste and connect with companies who can reuse it
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Button 
                className="flex items-center gap-2 bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                onClick={() => navigate('/user-dashboard/upload')}
              >
                <Upload className="h-4 w-4" /> Upload Plastic
              </Button>
              <Button 
                className="flex items-center gap-2" 
                variant="outline"
                onClick={() => navigate('/user-dashboard/my-uploads')}
              >
                <FolderOpen className="h-4 w-4" /> View My Uploads
              </Button>
              <Button 
                className="flex items-center gap-2" 
                variant="outline"
                onClick={() => navigate('/user-dashboard/profile')}
              >
                <User className="h-4 w-4" /> Update Profile
              </Button>
              <Button 
                className="flex items-center gap-2" 
                variant="outline"
                onClick={() => navigate('/user-dashboard/rewards')}
              >
                <Award className="h-4 w-4" /> Rewards ({userPoints} pts)
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Total Uploads</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{totalUploads}</p>
                  <p className="text-sm text-gray-500">{totalWeight} kg of plastic</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Approved Uploads</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{approvedUploads}</p>
                  <p className="text-sm text-gray-500">{approvedWeight} kg of plastic</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Environmental Impact</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{Math.round(approvedWeight * 1.5 * 10) / 10} kg</p>
                  <p className="text-sm text-gray-500">CO₂ emission saved</p>
                </>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Recent Uploads */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Uploads</CardTitle>
            <CardDescription>Your most recent plastic uploads</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              </div>
            ) : recentUploads.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">You have no uploads yet</p>
                <Button 
                  className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                  onClick={() => navigate('/user-dashboard/upload')}
                >
                  Upload Your First Plastic
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-2 font-medium">Type</th>
                      <th className="pb-2 font-medium">Quantity</th>
                      <th className="pb-2 font-medium">Status</th>
                      <th className="pb-2 font-medium">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentUploads.map(upload => (
                      <tr key={upload.id} className="border-b">
                        <td className="py-3">{upload.type}</td>
                        <td>{upload.quantity} {upload.unit}</td>
                        <td>
                          <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusBadgeClass(upload.status)}`}>
                            {getStatusDisplay(upload.status)}
                          </span>
                        </td>
                        <td>{upload.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default UserDashboard;
