
import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { FolderOpen, Building, FileCheck, Loader2 } from "lucide-react";

const CompanyDashboard = () => {
  const navigate = useNavigate();
  const [availablePlastics, setAvailablePlastics] = useState([]);
  const [orders, setOrders] = useState([]);
  const [totalKg, setTotalKg] = useState(0);
  const [loading, setLoading] = useState(true);
  const [pendingPayments, setPendingPayments] = useState(0);

  useEffect(() => {
    const loadData = () => {
      setLoading(true);
      try {
        // Load available plastics
        const storedPlastics = localStorage.getItem('availablePlastics');
        if (storedPlastics) {
          const plastics = JSON.parse(storedPlastics).filter(p => p.status === 'Available');
          setAvailablePlastics(plastics);
          console.log("Available plastics loaded:", plastics);
        } else {
          setAvailablePlastics([]);
          console.log("No available plastics found in localStorage");
        }
        
        // Load orders
        const storedOrders = localStorage.getItem('companyOrders');
        if (storedOrders) {
          const allOrders = JSON.parse(storedOrders);
          setOrders(allOrders);
          
          // Count pending payments
          const pending = allOrders.filter(order => order.status === 'Payment Pending').length;
          setPendingPayments(pending);
          
          // Calculate total kg
          let totalWeight = 0;
          allOrders.forEach(order => {
            const qtyMatch = order.quantity.match(/(\d+(\.\d+)?)\s*(kg|lb|pcs)/i);
            if (qtyMatch) {
              const qty = parseFloat(qtyMatch[1]);
              const unit = qtyMatch[3].toLowerCase();
              
              if (unit === 'kg') totalWeight += qty;
              else if (unit === 'lb') totalWeight += qty * 0.453592;
              else totalWeight += qty * 0.1; // rough estimate for pieces
            }
          });
          
          setTotalKg(Math.round(totalWeight * 10) / 10);
        } else {
          setOrders([]);
          setTotalKg(0);
          setPendingPayments(0);
        }
      } catch (error) {
        console.error("Error loading data:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
    
    // Listen for events that should trigger a refresh
    window.addEventListener('plasticCollected', () => {
      console.log("Plastic collected event received in CompanyDashboard");
      loadData();
    });
    
    // Set up interval to periodically refresh data
    const interval = setInterval(loadData, 5000);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('plasticCollected', loadData);
    };
  }, []);

  return (
    <DashboardLayout title="Company Dashboard" userType="company">
      <div className="grid gap-6">
        {/* Welcome Section */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Company Portal</CardTitle>
            <CardDescription>
              Find and acquire plastic waste materials for your recycling needs
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button 
                className="flex items-center gap-2 bg-ecoplastix-blue hover:bg-ecoplastix-blue-dark"
                onClick={() => navigate('/company-dashboard/available-plastics')}
              >
                <FolderOpen className="h-4 w-4" /> Browse Available Plastics
              </Button>
              <Button 
                className="flex items-center gap-2 bg-ecoplastix-green hover:bg-ecoplastix-green-dark" 
                onClick={() => navigate('/company-dashboard/orders')}
              >
                <FileCheck className="h-4 w-4" /> My Orders
                {pendingPayments > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 text-xs bg-red-500 text-white rounded-full">
                    {pendingPayments}
                  </span>
                )}
              </Button>
              <Button 
                className="flex items-center gap-2" 
                variant="outline"
                onClick={() => navigate('/company-dashboard/profile')}
              >
                <Building className="h-4 w-4" /> Update Company Profile
              </Button>
            </div>
            {pendingPayments > 0 && (
              <div className="mt-4 p-2 bg-yellow-50 border border-yellow-200 rounded-md">
                <p className="text-yellow-800 text-sm">
                  <strong>Attention:</strong> You have {pendingPayments} accepted bid{pendingPayments > 1 ? 's' : ''} waiting for payment. 
                  Please submit payment proof to complete your transaction.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Available Plastics</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{availablePlastics.length}</p>
                  <p className="text-sm text-gray-500">Items for bidding</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Orders Placed</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{orders.length}</p>
                  <p className="text-sm text-gray-500">{totalKg} kg of plastic</p>
                </>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Environmental Impact</CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              ) : (
                <>
                  <p className="text-3xl font-bold">{Math.round(totalKg * 1.5 * 10) / 10} kg</p>
                  <p className="text-sm text-gray-500">CO₂ emission saved</p>
                </>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Available Plastics */}
        <Card>
          <CardHeader className="flex flex-row justify-between items-center">
            <div>
              <CardTitle>Recently Available Plastics</CardTitle>
              <CardDescription>Plastic waste ready for collection</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/company-dashboard/available-plastics')}>
              View All
            </Button>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              </div>
            ) : availablePlastics.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No plastics available yet</p>
                <Button 
                  variant="outline" 
                  onClick={() => navigate('/company-dashboard/available-plastics')}
                >
                  Check Later
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-2 font-medium">Type</th>
                      <th className="pb-2 font-medium">Quantity</th>
                      <th className="pb-2 font-medium">Location</th>
                      <th className="pb-2 font-medium">User</th>
                      <th className="pb-2 font-medium">Date</th>
                      <th className="pb-2 font-medium"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {availablePlastics.slice(0, 5).map(plastic => (
                      <tr key={plastic.id} className="border-b">
                        <td className="py-3">{plastic.type}</td>
                        <td>{plastic.quantity}</td>
                        <td>{plastic.location}</td>
                        <td>{plastic.user}</td>
                        <td>{plastic.date}</td>
                        <td>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => navigate(`/company-dashboard/available-plastics?view=${plastic.id}`)}
                          >
                            View
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default CompanyDashboard;
