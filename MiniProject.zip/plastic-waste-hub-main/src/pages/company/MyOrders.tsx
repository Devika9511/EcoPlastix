
import { useState, useEffect, useRef } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Image, Upload, FileCheck, CreditCard, MessageSquare } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const MyOrders = () => {
  const { toast } = useToast();
  const [paymentProof, setPaymentProof] = useState(null);
  const [paymentPreview, setPaymentPreview] = useState(null);
  const [transactionId, setTransactionId] = useState("");
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const fileInputRef = useRef(null);
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [feedbackRating, setFeedbackRating] = useState(5);

  useEffect(() => {
    const loadOrders = () => {
      setLoading(true);
      try {
        const storedOrders = localStorage.getItem('companyOrders');
        if (storedOrders) {
          setOrders(JSON.parse(storedOrders));
        } else {
          setOrders([]);
        }
      } catch (error) {
        console.error("Error loading orders:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadOrders();
    
    // Set up interval to refresh orders
    const interval = setInterval(loadOrders, 5000);
    
    return () => clearInterval(interval);
  }, []);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setPaymentProof(e.target.files[0]);
      
      // Create a preview of the image
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          setPaymentPreview(e.target.result);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const submitPaymentProof = (orderId) => {
    if (!paymentProof) {
      toast({
        title: "No file selected",
        description: "Please upload a payment proof document.",
        variant: "destructive"
      });
      return;
    }

    if (!transactionId.trim()) {
      toast({
        title: "Transaction ID required",
        description: "Please enter the transaction ID for this payment.",
        variant: "destructive"
      });
      return;
    }

    // Update orders in localStorage
    const updatedOrders = orders.map(order => 
      order.id === orderId 
        ? { 
            ...order, 
            status: 'Payment Verification Pending', 
            paymentProofImage: paymentPreview,
            transactionId: transactionId 
          } 
        : order
    );
    
    setOrders(updatedOrders);
    localStorage.setItem('companyOrders', JSON.stringify(updatedOrders));
    
    // Update in admin dashboard
    const storedUploads = localStorage.getItem('adminUploads');
    if (storedUploads) {
      const uploads = JSON.parse(storedUploads);
      const updatedUploads = uploads.map(upload => {
        if (upload.id === orderId) {
          return {
            ...upload,
            paymentProof: paymentPreview,
            transactionId: transactionId,
            paymentStatus: 'Pending Verification'
          };
        }
        return upload;
      });
      localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    }
    
    toast({
      title: "Payment proof submitted",
      description: "Your payment proof and transaction ID have been submitted for verification.",
    });
    
    setPaymentProof(null);
    setPaymentPreview(null);
    setTransactionId("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    
    // Dispatch event to notify other components
    window.dispatchEvent(new Event('transactionUpdated'));
  };

  const submitFeedback = (orderId) => {
    if (!feedbackMessage.trim()) {
      toast({
        title: "Feedback required",
        description: "Please enter your feedback message.",
        variant: "destructive"
      });
      return;
    }
    
    const feedback = {
      id: Date.now(),
      orderId: orderId,
      company: localStorage.getItem('currentUser') || 'Anonymous Company',
      date: new Date().toISOString().split('T')[0],
      message: feedbackMessage,
      rating: feedbackRating
    };
    
    // Save feedback
    const storedFeedback = localStorage.getItem('companyFeedback');
    const feedbackArray = storedFeedback ? JSON.parse(storedFeedback) : [];
    feedbackArray.unshift(feedback);
    localStorage.setItem('companyFeedback', JSON.stringify(feedbackArray));
    
    toast({
      title: "Feedback submitted",
      description: "Thank you for your feedback!",
    });
    
    setFeedbackMessage("");
    setFeedbackRating(5);
    
    // Dispatch event
    window.dispatchEvent(new Event('feedbackSubmitted'));
  };

  return (
    <DashboardLayout title="My Orders" userType="company">
      <div className="grid gap-6">
        {orders.some(order => order.status === 'Payment Pending') && (
          <Card className="bg-yellow-50 border-yellow-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-yellow-800">
                <CreditCard className="h-5 w-5" />
                <h3 className="font-medium">Payment Required</h3>
              </div>
              <p className="text-yellow-700 mt-1 text-sm">
                You have orders that require payment. Please submit payment proof and transaction ID to complete your purchase.
              </p>
            </CardContent>
          </Card>
        )}
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileCheck className="h-5 w-5 text-ecoplastix-green" />
              My Plastic Orders
            </CardTitle>
            <CardDescription>
              Manage your purchased plastic waste items and payment status
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500">You haven't placed any orders yet.</p>
                <Button 
                  className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark mt-4"
                  onClick={() => window.location.href = '/company-dashboard/available-plastics'}
                >
                  Browse Available Plastics
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Seller</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map(order => (
                    <TableRow key={order.id} className={order.status === 'Payment Pending' ? 'bg-yellow-50' : ''}>
                      <TableCell>{order.type}</TableCell>
                      <TableCell>{order.quantity}</TableCell>
                      <TableCell>{order.user}</TableCell>
                      <TableCell>{order.date}</TableCell>
                      <TableCell>{order.amount}</TableCell>
                      <TableCell>
                        <Badge className={
                          order.status === 'Completed' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 
                          order.status === 'Payment Verification Pending' ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100' :
                          order.status === 'Payment Pending' ? 'bg-red-100 text-red-800 hover:bg-red-100' :
                          'bg-blue-100 text-blue-800 hover:bg-blue-100'
                        }>
                          {order.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="flex items-center gap-1">
                                <Image className="h-4 w-4" /> Images
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>{order.type} Images</DialogTitle>
                                <DialogDescription>
                                  Images of the plastic waste you purchased
                                </DialogDescription>
                              </DialogHeader>
                              <div className="grid grid-cols-2 gap-4 mt-4">
                                {order.images && order.images.map((img, idx) => (
                                  <div key={idx} className="border rounded-md overflow-hidden">
                                    <img src={img} alt={`Plastic order ${idx+1}`} className="w-full h-48 object-cover" />
                                  </div>
                                ))}
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          {order.status === 'Payment Pending' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm" 
                                  className="bg-ecoplastix-blue hover:bg-ecoplastix-blue-dark flex items-center gap-1"
                                >
                                  <CreditCard className="h-4 w-4" /> Submit Payment
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Submit Payment Proof</DialogTitle>
                                  <DialogDescription>
                                    Upload proof of payment for {order.type} ({order.amount})
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                  <div className="space-y-2">
                                    <Label htmlFor="transaction-id">Transaction ID</Label>
                                    <Input 
                                      id="transaction-id" 
                                      value={transactionId}
                                      onChange={(e) => setTransactionId(e.target.value)}
                                      placeholder="Enter transaction ID"
                                    />
                                  </div>
                                
                                  <div className="space-y-2">
                                    <Label htmlFor="payment-proof">Payment Proof Document</Label>
                                    <div className="flex items-center justify-center w-full">
                                      <label 
                                        htmlFor="payment-proof" 
                                        className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-md border-gray-300 cursor-pointer bg-gray-50 hover:bg-gray-100"
                                      >
                                        <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                          <Upload className="w-8 h-8 text-gray-500 mb-2" />
                                          <p className="text-sm text-gray-500">
                                            <span className="font-medium">Click to upload</span> or drag and drop
                                          </p>
                                          <p className="text-xs text-gray-500">
                                            PNG, JPG, JPEG, PDF up to 10MB
                                          </p>
                                        </div>
                                        <Input 
                                          id="payment-proof" 
                                          type="file" 
                                          className="hidden"
                                          accept="image/*,.pdf"
                                          onChange={handleFileChange}
                                          ref={fileInputRef}
                                        />
                                      </label>
                                    </div>
                                    {paymentProof && (
                                      <div className="mt-2">
                                        <p className="text-sm text-gray-600 mb-2">
                                          Selected file: {paymentProof.name}
                                        </p>
                                        {paymentPreview && (
                                          <div className="border rounded-md overflow-hidden h-32">
                                            <img
                                              src={paymentPreview}
                                              alt="Payment proof preview"
                                              className="w-full h-full object-cover"
                                            />
                                          </div>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                </div>
                                <DialogFooter>
                                  <Button type="submit" onClick={() => submitPaymentProof(order.id)}>
                                    Submit Payment Proof
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          )}
                          
                          {order.paymentProofImage && order.status === 'Payment Verification Pending' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  className="flex items-center gap-1"
                                >
                                  <FileCheck className="h-4 w-4" /> View Payment
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Payment Proof</DialogTitle>
                                  <DialogDescription>
                                    Your submitted payment proof (pending verification)
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4 mt-4">
                                  <div className="space-y-2">
                                    <Label>Transaction ID</Label>
                                    <div className="p-2 bg-gray-50 border rounded-md">
                                      {order.transactionId || 'Not provided'}
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-2">
                                    <Label>Payment Screenshot</Label>
                                    <div className="border rounded-md overflow-hidden">
                                      <img
                                        src={order.paymentProofImage}
                                        alt="Payment proof"
                                        className="w-full object-contain max-h-96"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}

                          {order.status === 'Completed' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm" 
                                  className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark flex items-center gap-1"
                                >
                                  <MessageSquare className="h-4 w-4" /> Submit Feedback
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Submit Feedback</DialogTitle>
                                  <DialogDescription>
                                    Share your experience about this transaction and the quality of plastic received
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                  <div className="space-y-2">
                                    <Label htmlFor="rating">Rating</Label>
                                    <div className="flex">
                                      {[1, 2, 3, 4, 5].map((star) => (
                                        <button
                                          key={star}
                                          type="button"
                                          onClick={() => setFeedbackRating(star)}
                                          className="text-2xl focus:outline-none"
                                        >
                                          <span className={star <= feedbackRating ? 'text-yellow-500' : 'text-gray-300'}>
                                            ★
                                          </span>
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                  <div className="space-y-2">
                                    <Label htmlFor="feedback">Your Feedback</Label>
                                    <Textarea 
                                      id="feedback"
                                      placeholder="Please share your experience with this transaction..."
                                      value={feedbackMessage}
                                      onChange={(e) => setFeedbackMessage(e.target.value)}
                                      rows={4}
                                    />
                                  </div>
                                </div>
                                <DialogFooter>
                                  <Button type="submit" onClick={() => submitFeedback(order.id)}>
                                    Submit Feedback
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default MyOrders;
