
import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Image, FolderOpen, Gavel } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const AvailablePlastics = () => {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const viewId = searchParams.get('view');
  const [bidAmount, setBidAmount] = useState("");
  const [plastics, setPlastics] = useState([]);
  const [loading, setLoading] = useState(true);

  // Get current company name for bid tracking
  const getCurrentCompany = () => {
    return localStorage.getItem('currentUser') || 'Company User';
  };

  // Load available plastics for bidding
  useEffect(() => {
    const loadPlastics = () => {
      setLoading(true);
      console.log("Loading available plastics in AvailablePlastics component");
      try {
        const currentCompany = getCurrentCompany();
        const storedPlastics = localStorage.getItem('availablePlastics');
        if (storedPlastics) {
          // Only show plastics that are still available (not sold)
          const availablePlastics = JSON.parse(storedPlastics).filter(
            plastic => plastic.status === 'Available' || plastic.status === 'Bid Accepted'
          );
          
          // Add company-specific bid information
          const plasticsWithCompanyBids = availablePlastics.map(plastic => {
            const companyBids = plastic.companyBids || {};
            const yourBidAmount = companyBids[currentCompany] || 0;
            return {
              ...plastic,
              yourBid: yourBidAmount > 0 ? `$${yourBidAmount}` : '-',
              yourBidAmount: yourBidAmount
            };
          });
          
          console.log("Available plastics found:", plasticsWithCompanyBids);
          setPlastics(plasticsWithCompanyBids);
        } else {
          console.log("No available plastics found in localStorage");
          setPlastics([]);
        }
      } catch (error) {
        console.error("Error loading plastics:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadPlastics();
    
    // Listen for plastic collection events
    const handlePlasticCollected = () => {
      console.log("Plastic collected event received in AvailablePlastics");
      loadPlastics();
    };
    
    window.addEventListener('plasticCollected', handlePlasticCollected);
    
    // Set up interval to refresh data
    const interval = setInterval(loadPlastics, 5000);
    
    return () => {
      clearInterval(interval);
      window.removeEventListener('plasticCollected', handlePlasticCollected);
    };
  }, []);
  
  useEffect(() => {
    if (viewId) {
      const found = plastics.find(plastic => plastic.id === viewId);
      if (found) {
        document.getElementById(`plastic-row-${viewId}`)?.scrollIntoView({ behavior: 'smooth' });
        // Highlight the row
        setTimeout(() => {
          const element = document.getElementById(`plastic-row-${viewId}`);
          if (element) {
            element.classList.add('bg-gray-100');
            setTimeout(() => {
              element.classList.remove('bg-gray-100');
            }, 2000);
          }
        }, 500);
      }
    }
  }, [viewId, plastics]);

  const handleBid = (plasticId) => {
    if (!bidAmount) {
      toast({
        title: "Invalid bid amount",
        description: "Please enter a valid bid amount.",
        variant: "destructive"
      });
      return;
    }
    
    const amount = parseFloat(bidAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid bid amount",
        description: "Bid amount must be a positive number.",
        variant: "destructive"
      });
      return;
    }
    
    const currentCompany = getCurrentCompany();
    
    // Find the plastic to check if the new bid is higher than current highest bid
    const plastic = plastics.find(p => p.id === plasticId);
    if (plastic && amount <= (plastic.highestBidAmount || 0)) {
      toast({
        title: "Bid too low",
        description: `Your bid must be higher than the current highest bid (${plastic.highestBid || '$0'}).`,
        variant: "destructive"
      });
      return;
    }
    
    // Update local state with company-specific bid tracking
    setPlastics(plastics.map(plastic => {
      if (plastic.id === plasticId) {
        const isHighest = amount > (plastic.highestBidAmount || 0);
        return {
          ...plastic,
          highestBid: isHighest ? `$${amount}` : plastic.highestBid,
          highestBidAmount: isHighest ? amount : plastic.highestBidAmount,
          yourBid: `$${amount}`,
          yourBidAmount: amount
        };
      }
      return plastic;
    }));
    
    // Update in localStorage with company-specific bid tracking
    const storedPlastics = localStorage.getItem('availablePlastics');
    if (storedPlastics) {
      const allPlastics = JSON.parse(storedPlastics);
      const updatedPlastics = allPlastics.map(plastic => {
        if (plastic.id === plasticId) {
          const isHighest = amount > (plastic.highestBidAmount || 0);
          const companyBids = plastic.companyBids || {};
          companyBids[currentCompany] = amount;
          
          return {
            ...plastic,
            highestBid: isHighest ? `$${amount}` : plastic.highestBid,
            highestBidAmount: isHighest ? amount : plastic.highestBidAmount,
            companyBids: companyBids
          };
        }
        return plastic;
      });
      localStorage.setItem('availablePlastics', JSON.stringify(updatedPlastics));
    }
    
    // Add bid to adminUploads
    const storedUploads = localStorage.getItem('adminUploads');
    if (storedUploads) {
      const uploads = JSON.parse(storedUploads);
      const updatedUploads = uploads.map(upload => {
        if (upload.id === plasticId) {
          const existingBids = upload.bids || [];
          const newBid = {
            id: Date.now().toString(),
            company: currentCompany,
            amount: amount,
            status: 'Pending'
          };
          
          // Only add if there isn't already a bid from this company with same amount
          let updatedBids = [...existingBids];
          const existingCompanyBidIndex = existingBids.findIndex(
            bid => bid.company === currentCompany
          );
          
          if (existingCompanyBidIndex >= 0) {
            // Update existing bid from this company
            updatedBids[existingCompanyBidIndex] = {
              ...updatedBids[existingCompanyBidIndex],
              amount: amount,
              status: 'Pending'
            };
          } else {
            // Add new bid
            updatedBids.push(newBid);
          }
          
          return {
            ...upload,
            bids: updatedBids
          };
        }
        return upload;
      });
      localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    }
    
    toast({
      title: "Bid placed successfully",
      description: `Your bid of $${amount} has been placed. Admin will review all bids.`,
    });
    
    setBidAmount("");
  };

  return (
    <DashboardLayout title="Available Plastics" userType="company">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-ecoplastix-green" />
            Available Plastic Waste
          </CardTitle>
          <CardDescription>
            Browse and bid on available plastic waste uploads
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          ) : plastics.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No plastic waste uploads available at this time.</p>
              <p className="text-sm text-gray-500 mt-2">Check back soon as users upload more plastic waste.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b">
                    <th className="pb-2 font-medium">Type</th>
                    <th className="pb-2 font-medium">Quantity</th>
                    <th className="pb-2 font-medium">Location</th>
                    <th className="pb-2 font-medium">Date</th>
                    <th className="pb-2 font-medium">Status</th>
                    <th className="pb-2 font-medium">Highest Bid</th>
                    <th className="pb-2 font-medium">Your Bid</th>
                    <th className="pb-2 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {plastics.map(plastic => (
                    <tr 
                      key={plastic.id} 
                      className={`border-b transition-colors ${plastic.status !== 'Available' ? 'bg-gray-50 text-gray-500' : ''}`}
                      id={`plastic-row-${plastic.id}`}
                    >
                      <td className="py-3">{plastic.type}</td>
                      <td>{plastic.quantity}</td>
                      <td>{plastic.location}</td>
                      <td>{plastic.date}</td>
                      <td>
                        <Badge className={
                          plastic.status === 'Available' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 
                          plastic.status === 'Bid Accepted' ? 'bg-blue-100 text-blue-800 hover:bg-blue-100' :
                          'bg-gray-100 text-gray-800 hover:bg-gray-100'
                        }>
                          {plastic.status}
                        </Badge>
                      </td>
                      <td>{plastic.highestBid || 'No bids yet'}</td>
                      <td>{plastic.yourBid || '-'}</td>
                      <td>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="flex items-center gap-1">
                                <Image className="h-4 w-4" /> Images
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>{plastic.type} Images</DialogTitle>
                                <DialogDescription>
                                  Images of the plastic waste uploaded by {plastic.user}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="grid grid-cols-2 gap-4 mt-4">
                                {plastic.images && plastic.images.map((img, idx) => (
                                  <div key={idx} className="border rounded-md overflow-hidden">
                                    <img src={img} alt={`Plastic upload ${idx+1}`} className="w-full h-48 object-cover" />
                                  </div>
                                ))}
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          {plastic.status === 'Bid Accepted' && plastic.yourBidAmount === plastic.highestBidAmount && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm" 
                                  className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark flex items-center gap-1"
                                >
                                  Submit Payment
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Your Bid Has Been Accepted!</DialogTitle>
                                  <DialogDescription>
                                    Congratulations! Your bid of {plastic.yourBid} for {plastic.type} has been accepted.
                                    Please proceed to payment.
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="mt-4">
                                  <p className="text-sm">
                                    Please go to the "My Orders" page to submit your payment proof and transaction ID.
                                  </p>
                                  <Button 
                                    className="w-full mt-4"
                                    onClick={() => window.location.href = '/company-dashboard/orders'}
                                  >
                                    Go to My Orders
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                          
                          {plastic.status === 'Available' && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm" 
                                  className="bg-ecoplastix-blue hover:bg-ecoplastix-blue-dark flex items-center gap-1"
                                >
                                  <Gavel className="h-4 w-4" /> Place Bid
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Place a Bid</DialogTitle>
                                  <DialogDescription>
                                    Enter your bid amount for {plastic.type} ({plastic.quantity})
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="grid gap-4 py-4">
                                  <div className="space-y-2">
                                    <Label htmlFor="amount">Bid Amount ($)</Label>
                                    <Input
                                      id="amount"
                                      type="number"
                                      min="1"
                                      step="1"
                                      value={bidAmount}
                                      onChange={(e) => setBidAmount(e.target.value)}
                                      placeholder="Enter bid amount"
                                    />
                                    <p className="text-sm text-muted-foreground">
                                      Current highest bid: {plastic.highestBid || 'No bids yet'}
                                    </p>
                                    {plastic.yourBid && plastic.yourBid !== '-' && (
                                      <p className="text-sm text-muted-foreground">
                                        Your current bid: {plastic.yourBid}
                                      </p>
                                    )}
                                  </div>
                                </div>
                                <DialogFooter>
                                  <Button type="submit" onClick={() => handleBid(plastic.id)}>
                                    Submit Bid
                                  </Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
};

export default AvailablePlastics;
