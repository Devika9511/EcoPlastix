
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Upload, Building, User, RecycleIcon, Leaf } from "lucide-react";
import Logo from "@/components/Logo";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Navigation */}
      <Navbar />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-ecoplastix-green-light/30 to-ecoplastix-blue-light flex-grow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div className="animate-fade-in animate-[slide-in-right_1s_ease-out]">
              <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl md:text-6xl mb-6">
                <span className="inline-block animate-[slide-in-right_1.2s_ease-out]">Turning Plastic Waste</span>
                <span className="block text-ecoplastix-green mt-2 animate-[slide-in-right_1.4s_ease-out]">Into Value</span>
              </h1>
              <p className="mt-3 text-lg text-gray-600 sm:text-xl animate-[slide-in-right_1.6s_ease-out]">
                Join our mission to reduce plastic waste by participating in our recycling
                program. Upload your plastic waste details and help us build a more
                sustainable future with EcoPlastix.
              </p>
              <div className="mt-8 flex flex-wrap gap-4 animate-[slide-in-right_1.8s_ease-out]">
                <Link to="/signup">
                  <Button className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark text-white">
                    Join Now
                  </Button>
                </Link>
                <Link to="/about">
                  <Button variant="outline">
                    Learn More
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden lg:block animate-[slide-in-left_1s_ease-out]">
              <img 
                src="/lovable-uploads/f166a45b-2c98-4136-b168-a4bf9639ea77.png" 
                alt="Plastic recycling illustration" 
                className="w-full max-w-md mx-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">How <span className="text-ecoplastix-green-light">Eco</span><span className="text-ecoplastix-green-dark">Plastix</span> Works</h2>
            <p className="mt-4 text-lg text-gray-600">
              A simple three-step process to transform plastic waste into valuable resources
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Step 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-ecoplastix-green-light/20 flex items-center justify-center mb-4">
                <Upload className="h-8 w-8 text-ecoplastix-green-light" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Upload Your Plastic</h3>
              <p className="text-gray-600">
                Individuals upload details and images of their plastic waste materials
              </p>
            </div>

            {/* Step 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-ecoplastix-blue-light flex items-center justify-center mb-4">
                <User className="h-8 w-8 text-ecoplastix-blue" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Admin Verification</h3>
              <p className="text-gray-600">
                Our admin team verifies the uploads and approves them for companies
              </p>
            </div>

            {/* Step 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full bg-ecoplastix-green-dark/20 flex items-center justify-center mb-4">
                <Building className="h-8 w-8 text-ecoplastix-green-dark" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Company Connection</h3>
              <p className="text-gray-600">
                Recycling companies browse and connect with individuals to collect materials
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900">Benefits</h2>
            <p className="mt-4 text-lg text-gray-600">
              Why choose EcoPlastix for your plastic waste management
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium text-ecoplastix-green mb-2">Eco-Friendly</h3>
              <p className="text-gray-600">
                Reduce landfill waste and promote recycling of plastics
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium text-ecoplastix-green mb-2">Efficiency</h3>
              <p className="text-gray-600">
                Streamlined process connects waste sources directly with recyclers
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium text-ecoplastix-green mb-2">Transparency</h3>
              <p className="text-gray-600">
                Track your contributions and see the environmental impact
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-medium text-ecoplastix-green mb-2">Community</h3>
              <p className="text-gray-600">
                Join a network of environmentally conscious individuals and companies
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-ecoplastix-green-light to-ecoplastix-green-dark py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white">Join Our Plastic Management Initiative</h2>
            <p className="mt-4 text-lg text-white/80">
              Whether you're an individual looking to responsibly dispose of plastic waste or a
              company seeking sustainable materials, EcoPlastix connects you to a greener future.
            </p>
            <div className="mt-8">
              <Link to="/signup">
                <Button className="bg-white text-ecoplastix-green-dark hover:bg-gray-100">
                  Get Started Today
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Index;
