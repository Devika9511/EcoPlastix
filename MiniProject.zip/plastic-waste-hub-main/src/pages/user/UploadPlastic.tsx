import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Upload, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const UploadPlastic = () => {
  const [plasticType, setPlasticType] = useState("");
  const [quantity, setQuantity] = useState("");
  const [unit, setUnit] = useState("kg");
  const [description, setDescription] = useState("");
  const [location, setLocation] = useState("");
  const [images, setImages] = useState<FileList | null>(null);
  const [imageError, setImageError] = useState(false);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Validate if images are uploaded (now mandatory)
    if (!images || images.length === 0) {
      setImageError(true);
      toast({
        title: "Images required",
        description: "Please upload at least one image of your plastic waste.",
        variant: "destructive"
      });
      return;
    }
    
    // Get today's date formatted as YYYY-MM-DD
    const today = new Date().toISOString().split('T')[0];
    
    // Create an upload object with initial status "Collection Pending"
    const uploadData = {
      id: Date.now().toString(),
      type: plasticType === 'pet' ? 'PET' : 
            plasticType === 'hdpe' ? 'HDPE' : 
            plasticType === 'pvc' ? 'PVC' : 
            plasticType === 'ldpe' ? 'LDPE' : 
            plasticType === 'pp' ? 'PP' : 
            plasticType === 'ps' ? 'PS' : 'Other',
      quantity,
      unit,
      description,
      location,
      date: today,
      status: 'Collection Pending',
      imageUrls: imagePreviews,
      imageNames: Array.from(images).map(img => img.name),
      bids: []
    };
    
    // In a real app with Supabase, this would store to the database
    // For now, we'll store in localStorage
    try {
      const storedUploads = localStorage.getItem('userUploads');
      let uploads = storedUploads ? JSON.parse(storedUploads) : [];
      uploads.unshift(uploadData);
      localStorage.setItem('userUploads', JSON.stringify(uploads));
      
      // Also update admin uploads
      const storedAdminUploads = localStorage.getItem('adminUploads');
      let adminUploads = storedAdminUploads ? JSON.parse(storedAdminUploads) : [];
      adminUploads.unshift({
        ...uploadData,
        user: localStorage.getItem('currentUser') || 'Anonymous User'
      });
      localStorage.setItem('adminUploads', JSON.stringify(adminUploads));
      
      // Dispatch event to notify other components
      window.dispatchEvent(new Event('plasticUploaded'));
    } catch (error) {
      console.error("Error saving upload:", error);
    }
    
    toast({
      title: "Upload successful",
      description: "Your plastic upload has been submitted and is pending collection.",
    });
    
    // Redirect back to dashboard after short delay
    setTimeout(() => {
      navigate('/user-dashboard/my-uploads');
    }, 1500);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setImages(e.target.files);
      setImageError(false);
      
      // Clear previous previews
      setImagePreviews([]);
      
      // Generate new previews
      Array.from(e.target.files).forEach(file => {
        const reader = new FileReader();
        reader.onload = (event: ProgressEvent<FileReader>) => {
          if (event.target?.result) {
            setImagePreviews(prev => [...prev, event.target!.result as string]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };
  
  const clearImages = () => {
    setImages(null);
    setImagePreviews([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <DashboardLayout title="Upload Plastic" userType="user">
      <Card className="max-w-2xl mx-auto">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle>Upload Your Plastic Waste</CardTitle>
            <CardDescription>
              Provide details about the plastic waste you have available for recycling
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="plasticType">Plastic Type</Label>
              <Select value={plasticType} onValueChange={setPlasticType} required>
                <SelectTrigger id="plasticType">
                  <SelectValue placeholder="Select plastic type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pet">PET (Polyethylene Terephthalate)</SelectItem>
                  <SelectItem value="hdpe">HDPE (High-Density Polyethylene)</SelectItem>
                  <SelectItem value="pvc">PVC (Polyvinyl Chloride)</SelectItem>
                  <SelectItem value="ldpe">LDPE (Low-Density Polyethylene)</SelectItem>
                  <SelectItem value="pp">PP (Polypropylene)</SelectItem>
                  <SelectItem value="ps">PS (Polystyrene)</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input 
                  id="quantity" 
                  type="number"
                  min="0.1"
                  step="0.1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="unit">Unit</Label>
                <Select value={unit} onValueChange={setUnit} required>
                  <SelectTrigger id="unit">
                    <SelectValue placeholder="Select unit" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="kg">Kilograms (kg)</SelectItem>
                    <SelectItem value="lb">Pounds (lb)</SelectItem>
                    <SelectItem value="pcs">Pieces</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input 
                id="location" 
                placeholder="City, State"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea 
                id="description"
                placeholder="Provide additional details about your plastic waste..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="images" className="flex items-center">
                Upload Images <span className="text-red-500 ml-1">*</span>
              </Label>
              <div className="flex items-center justify-center w-full">
                <label 
                  htmlFor="images" 
                  className={`flex flex-col items-center justify-center w-full h-32 border-2 ${imageError ? 'border-red-400 bg-red-50' : 'border-gray-300 bg-gray-50'} border-dashed rounded-md cursor-pointer hover:bg-gray-100`}
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className={`w-8 h-8 ${imageError ? 'text-red-500' : 'text-gray-500'} mb-2`} />
                    <p className={`text-sm ${imageError ? 'text-red-500' : 'text-gray-500'}`}>
                      <span className="font-medium">Click to upload</span> or drag and drop
                    </p>
                    <p className={`text-xs ${imageError ? 'text-red-500' : 'text-gray-500'}`}>
                      PNG, JPG, JPEG up to 10MB (Required)
                    </p>
                  </div>
                  <Input 
                    id="images" 
                    type="file" 
                    className="hidden"
                    accept="image/*"
                    multiple
                    onChange={handleFileChange}
                    required
                    ref={fileInputRef}
                  />
                </label>
              </div>
              {imageError && (
                <p className="text-sm text-red-500 mt-2">
                  At least one image is required
                </p>
              )}
              {images && images.length > 0 && (
                <div className="mt-4">
                  <div className="flex justify-between items-center mb-2">
                    <p className="text-sm text-gray-600">
                      {images.length} {images.length === 1 ? 'file' : 'files'} selected
                    </p>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="sm" 
                      className="text-red-500 hover:text-red-700"
                      onClick={clearImages}
                    >
                      <X className="h-4 w-4 mr-1" /> Clear
                    </Button>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {imagePreviews.map((preview, index) => (
                      <div key={index} className="border rounded overflow-hidden h-24">
                        <img 
                          src={preview} 
                          alt={`Preview ${index + 1}`} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-end space-x-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={() => navigate('/user-dashboard')}
            >
              Cancel
            </Button>
            <Button type="submit" className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark">
              Submit Upload
            </Button>
          </CardFooter>
        </form>
      </Card>
    </DashboardLayout>
  );
};

export default UploadPlastic;
