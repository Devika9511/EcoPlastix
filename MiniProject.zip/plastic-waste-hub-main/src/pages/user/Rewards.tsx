
import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Award, ShoppingCart, ExternalLink, Gift, Video } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const Rewards = () => {
  const { toast } = useToast();
  const [userPoints, setUserPoints] = useState(0);
  const [rewards] = useState([
    { 
      id: 1, 
      name: 'Amazon Gift Card', 
      points: 100, 
      description: '$10 Amazon Gift Card', 
      store: 'Amazon',
      storeUrl: 'https://www.amazon.com',
      image: 'https://m.media-amazon.com/images/G/01/gc/designs/livepreview/a_generic_white_10_us_noto_email_v2016_us-main._CB627448186_.png',
      longDescription: 'Get a $10 Amazon Gift Card that can be used to purchase millions of items across Amazon. Perfect for buying books, electronics, household items, and more.'
    },
    { 
      id: 2, 
      name: 'Meesho Discount Coupon', 
      points: 50, 
      description: '15% off on your next Meesho purchase', 
      store: 'Meesho',
      storeUrl: 'https://www.meesho.com',
      image: 'https://images.meesho.com/images/marketing/1661417516766.webp',
      longDescription: 'Get 15% off your next purchase on Meesho. This discount can be applied to fashion, home goods, beauty products, and more. Maximum discount value of $25.'
    },
    { 
      id: 3, 
      name: 'Amazon Prime Subscription', 
      points: 500, 
      description: '1 month of Amazon Prime', 
      store: 'Amazon',
      storeUrl: 'https://www.amazon.com/prime',
      image: 'https://m.media-amazon.com/images/G/01/marketing/prime/Brand/JD/2021/Jan/Phase2/Prime_Logo_Blue_Badge._CB485922519_.png',
      longDescription: 'Enjoy one month of Amazon Prime membership including free shipping, Prime Video, Prime Music, Prime Reading, and exclusive Prime deals.'
    },
    { 
      id: 4, 
      name: 'Meesho Free Shipping', 
      points: 75, 
      description: 'Free shipping on your next Meesho order', 
      store: 'Meesho',
      storeUrl: 'https://www.meesho.com',
      image: 'https://images.meesho.com/images/marketing/1678691775656.png',
      longDescription: 'Get free shipping on your next order from Meesho, no minimum purchase required. Valid for orders within the country only.'
    }
  ]);
  const [redeemHistory, setRedeemHistory] = useState([]);
  const [showCodeDialog, setShowCodeDialog] = useState(false);
  const [showTutorialDialog, setShowTutorialDialog] = useState(false);
  const [currentCode, setCurrentCode] = useState("");
  const [currentStore, setCurrentStore] = useState("");
  const [currentStoreUrl, setCurrentStoreUrl] = useState("");

  // Load points from localStorage
  useEffect(() => {
    const storedPoints = localStorage.getItem('userPoints');
    if (storedPoints) {
      setUserPoints(parseInt(storedPoints));
    } else {
      localStorage.setItem('userPoints', '0');
    }
    
    const storedHistory = localStorage.getItem('redeemHistory');
    if (storedHistory) {
      setRedeemHistory(JSON.parse(storedHistory));
    }
  }, []);

  const generateRedeemCode = (rewardName: string) => {
    if (rewardName.includes('Amazon')) {
      return `AMZN-${Math.random().toString(36).substring(2, 5)}-${Math.random().toString(36).substring(2, 5)}`;
    } else if (rewardName.includes('Meesho')) {
      return `MEESHO${Math.random().toString(36).toUpperCase().substring(2, 8)}`;
    } else {
      return `ECOPLAS${Math.random().toString(36).toUpperCase().substring(2, 8)}`;
    }
  };

  const handleRedeem = (rewardId: number, rewardName: string, store: string, storeUrl: string, points: number) => {
    // Generate code for the reward
    const code = generateRedeemCode(rewardName);
    
    // Add to redemption history
    const newRedemption = {
      id: Date.now(),
      rewardName,
      points,
      date: new Date().toISOString().split('T')[0],
      code
    };
    
    const updatedHistory = [newRedemption, ...redeemHistory];
    setRedeemHistory(updatedHistory);
    localStorage.setItem('redeemHistory', JSON.stringify(updatedHistory));
    
    // Update points
    const newPoints = userPoints - points;
    setUserPoints(newPoints);
    localStorage.setItem('userPoints', newPoints.toString());
    
    // Show code dialog
    setCurrentCode(code);
    setCurrentStore(store);
    setCurrentStoreUrl(storeUrl);
    setShowCodeDialog(true);
    
    toast({
      title: "Reward redeemed successfully!",
      description: `You have redeemed ${rewardName} for ${points} points.`,
    });
  };

  return (
    <DashboardLayout title="Rewards" userType="user">
      <div className="grid gap-6">
        {/* Points Summary */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-ecoplastix-green" />
              Your Eco Rewards
            </CardTitle>
            <CardDescription>
              Redeem your points for rewards from Amazon and Meesho
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="text-center">
                <h3 className="text-lg font-semibold">Available Points</h3>
                <p className="text-4xl font-bold text-ecoplastix-green">{userPoints}</p>
                <p className="text-sm text-gray-500 mt-2">Earn points when your plastic is sold to companies!</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Code Dialog */}
        <Dialog open={showCodeDialog} onOpenChange={setShowCodeDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5 text-ecoplastix-green" /> Redemption Successful!
              </DialogTitle>
              <DialogDescription>
                Here's your code for {currentStore}
              </DialogDescription>
            </DialogHeader>
            <div className="mt-4 space-y-6">
              <div className="p-4 border-2 border-dashed border-ecoplastix-green rounded-md bg-gray-50">
                <p className="text-center text-lg font-mono font-bold">{currentCode}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm text-gray-600">How to use your code:</p>
                <ol className="list-decimal list-inside text-sm text-gray-600 space-y-1">
                  <li>Copy the code above</li>
                  <li>Go to {currentStore}'s website</li>
                  <li>Apply the code during checkout</li>
                  <li>Enjoy your reward!</li>
                </ol>
              </div>
              <div className="flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setShowCodeDialog(false);
                    setShowTutorialDialog(true);
                  }}
                >
                  View Tutorial
                </Button>
                <Button 
                  className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                  onClick={() => {
                    window.open(currentStoreUrl, '_blank');
                    setShowCodeDialog(false);
                  }}
                >
                  Go to {currentStore} Now
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        
        {/* Tutorial Dialog */}
        <Dialog open={showTutorialDialog} onOpenChange={setShowTutorialDialog}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Video className="h-5 w-5 text-ecoplastix-green" /> How to Redeem Your Code
              </DialogTitle>
              <DialogDescription>
                Follow this tutorial to redeem your gift card or discount code
              </DialogDescription>
            </DialogHeader>
            <div className="mt-4 space-y-6">
              <div className="rounded-md overflow-hidden aspect-video">
                <iframe
                  width="100%"
                  height="315"
                  src="https://www.youtube.com/embed/dQw4w9WgXcQ"
                  title="Gift Card Redemption Tutorial"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  className="w-full aspect-video"
                ></iframe>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Step-by-step Instructions:</h4>
                <ol className="list-decimal list-outside ml-4 text-sm text-gray-600 space-y-3">
                  <li>Copy your unique code from the previous screen</li>
                  <li>Visit the retailer's website (Amazon or Meesho) and add your desired items to cart</li>
                  <li>Proceed to checkout and locate the "Gift Cards & Promotions" or "Promo Code" section (usually before payment)</li>
                  <li>Paste your code in the designated field and click "Apply"</li>
                  <li>Verify that the discount has been applied before completing your purchase</li>
                  <li>Complete your purchase and enjoy your reward!</li>
                </ol>
              </div>
              <Button onClick={() => setShowTutorialDialog(false)}>
                Close Tutorial
              </Button>
            </div>
          </DialogContent>
        </Dialog>
        
        {/* Redemption Instructions */}
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="pb-2">
            <CardTitle className="text-md flex items-center gap-2">
              <ShoppingCart className="h-5 w-5 text-blue-500" />
              How to Redeem Points
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2 text-sm text-gray-700">
              <li>Select a reward from the available options below</li>
              <li>Click the <strong>Redeem</strong> button (you must have enough points)</li>
              <li>You'll receive a confirmation with your code</li>
              <li>For gift cards, use the code during checkout on the retailer's site</li>
              <li>For discounts, apply the coupon code at the payment step</li>
              <li><Button 
                    variant="link" 
                    className="p-0 h-auto text-blue-600"
                    onClick={() => setShowTutorialDialog(true)}
                  >
                    Watch our tutorial video
                  </Button> for a step-by-step guide on redeeming codes</li>
            </ol>
          </CardContent>
        </Card>
        
        {/* Available Rewards */}
        <h3 className="text-xl font-semibold mt-2">Available Rewards</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {rewards.map(reward => (
            <Card key={reward.id} className="overflow-hidden">
              <div className="h-40 overflow-hidden bg-gray-100 flex items-center justify-center">
                <img src={reward.image} alt={reward.name} className="w-full h-full object-contain" />
              </div>
              <CardHeader className="pb-2 pt-4">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">{reward.name}</CardTitle>
                  <Badge className="bg-ecoplastix-green text-white">{reward.points} pts</Badge>
                </div>
                <CardDescription>{reward.description}</CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="flex items-center gap-1 text-sm text-gray-500">
                  <ExternalLink className="h-4 w-4" /> 
                  Redeemable at {reward.store}
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" className="w-full">View Details</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{reward.name}</DialogTitle>
                      <DialogDescription>
                        {reward.points} points - Redeemable at {reward.store}
                      </DialogDescription>
                    </DialogHeader>
                    <div className="mt-4 space-y-4">
                      <div className="border rounded-md overflow-hidden bg-gray-100 flex items-center justify-center h-48">
                        <img src={reward.image} alt={reward.name} className="w-full h-full object-contain" />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">Description</h4>
                        <p className="text-sm text-gray-600">{reward.longDescription}</p>
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">Redemption Process</h4>
                        <ol className="list-decimal list-inside text-sm text-gray-600 space-y-1">
                          <li>Click "Redeem" (requires {reward.points} points)</li>
                          <li>You'll receive a code for {reward.store}</li>
                          <li>Follow the instructions to apply your code at checkout</li>
                          <li>Watch our tutorial video for detailed guidance</li>
                        </ol>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                
                <Button 
                  className="w-full bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                  disabled={userPoints < reward.points}
                  onClick={() => handleRedeem(reward.id, reward.name, reward.store, reward.storeUrl, reward.points)}
                >
                  {userPoints >= reward.points ? 'Redeem' : 'Not Enough Points'}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        {/* Redemption History */}
        {redeemHistory.length > 0 && (
          <>
            <h3 className="text-xl font-semibold mt-4">Redemption History</h3>
            <Card>
              <CardContent className="pt-6">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-2 font-medium">Reward</th>
                      <th className="pb-2 font-medium">Points Used</th>
                      <th className="pb-2 font-medium">Date</th>
                      <th className="pb-2 font-medium">Code</th>
                    </tr>
                  </thead>
                  <tbody>
                    {redeemHistory.map(history => (
                      <tr key={history.id} className="border-b">
                        <td className="py-3">{history.rewardName}</td>
                        <td>{history.points}</td>
                        <td>{history.date}</td>
                        <td>
                          <code className="bg-gray-100 px-2 py-1 rounded text-sm">{history.code}</code>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Rewards;
