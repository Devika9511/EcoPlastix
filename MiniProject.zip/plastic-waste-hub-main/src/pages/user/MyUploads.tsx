
import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Image, Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const MyUploads = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [uploads, setUploads] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // In a real app with Supabase, this would fetch user uploads
    // For now, we'll simulate this with localStorage
    const fetchUploads = () => {
      setLoading(true);
      try {
        const storedUploads = localStorage.getItem('userUploads');
        if (storedUploads) {
          setUploads(JSON.parse(storedUploads));
        }
      } catch (error) {
        console.error("Error fetching uploads:", error);
        toast({
          title: "Error",
          description: "Could not fetch your uploads. Please try again.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchUploads();
    
    // Listen for upload events
    window.addEventListener('plasticUploaded', fetchUploads);
    
    return () => {
      window.removeEventListener('plasticUploaded', fetchUploads);
    };
  }, [toast]);

  // Helper function to get the appropriate badge color based on status
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'Approved':
        return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'Collected':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-100';
      case 'Bid Accepted':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100';
      case 'Sold':
        return 'bg-purple-100 text-purple-800 hover:bg-purple-100';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-100';
    }
  };

  // Helper function to get user-friendly status description
  const getStatusDescription = (status) => {
    switch (status) {
      case 'Approved':
        return 'Awaiting Collection';
      case 'Collected':
        return 'Collected - Awaiting Bids';
      case 'Bid Accepted':
        return 'Bid Accepted - Awaiting Payment';
      case 'Sold':
        return 'Sold - Transaction Complete';
      default:
        return status || 'Pending Approval';
    }
  };

  return (
    <DashboardLayout title="My Uploads" userType="user">
      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>Your Plastic Uploads</CardTitle>
                <CardDescription>View and manage all your plastic uploads</CardDescription>
              </div>
              <Button 
                className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                onClick={() => navigate('/user-dashboard/upload')}
              >
                New Upload
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-ecoplastix-green" />
              </div>
            ) : uploads.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">You haven't uploaded any plastic waste yet.</p>
                <Button 
                  className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                  onClick={() => navigate('/user-dashboard/upload')}
                >
                  Upload Your First Plastic
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b">
                      <th className="pb-2 font-medium">Type</th>
                      <th className="pb-2 font-medium">Quantity</th>
                      <th className="pb-2 font-medium">Location</th>
                      <th className="pb-2 font-medium">Date</th>
                      <th className="pb-2 font-medium">Status</th>
                      <th className="pb-2 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {uploads.map(upload => (
                      <tr key={upload.id} className="border-b">
                        <td className="py-3">{upload.type}</td>
                        <td>{upload.quantity} {upload.unit}</td>
                        <td>{upload.location}</td>
                        <td>{upload.date}</td>
                        <td>
                          <Badge className={getStatusBadgeClass(upload.status)}>
                            {getStatusDescription(upload.status)}
                          </Badge>
                        </td>
                        <td>
                          <div className="flex gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" className="flex items-center gap-1">
                                  <Image className="h-4 w-4" /> Images
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>{upload.type} Images</DialogTitle>
                                  <DialogDescription>
                                    Images of your uploaded plastic waste
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="grid grid-cols-2 gap-4 mt-4">
                                  {upload.imageUrls && upload.imageUrls.map((img, idx) => (
                                    <div key={idx} className="border rounded-md overflow-hidden">
                                      <img src={img} alt={`Plastic upload ${idx+1}`} className="w-full h-48 object-cover" />
                                    </div>
                                  ))}
                                  {!upload.imageUrls && upload.imageNames && (
                                    <div className="border rounded-md overflow-hidden p-4 text-center">
                                      <p>{upload.imageNames.join(', ')}</p>
                                    </div>
                                  )}
                                </div>
                              </DialogContent>
                            </Dialog>
                            
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default MyUploads;
