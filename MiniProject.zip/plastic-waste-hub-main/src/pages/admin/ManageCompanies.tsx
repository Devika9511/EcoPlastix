
import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const ManageCompanies = () => {
  const { toast } = useToast();
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadCompanies = () => {
    setLoading(true);
    try {
      // Force clear any existing data first
      localStorage.removeItem('dataCleanupComplete');
      
      // Set the real company data directly
      const realCompanyData = [
        {
          id: "1",
          name: "EcoRecycle Inc.",
          email: "contact@ecorecycle.com",
          status: "Verified",
          purchasedPlastic: "58 kg",
          totalTransactions: 12
        },
        {
          id: "2",
          name: "GreenTransform Ltd.",
          email: "info@greentransform.com",
          status: "Verified",
          purchasedPlastic: "32 kg",
          totalTransactions: 8
        },
        {
          id: "3",
          name: "Plastic2Products",
          email: "support@p2p.com",
          status: "Pending",
          purchasedPlastic: "0 kg",
          totalTransactions: 5
        },
        {
          id: "4",
          name: "RecycleMasters",
          email: "hello@recyclemasters.com",
          status: "Verified",
          purchasedPlastic: "120 kg",
          totalTransactions: 18
        }
      ];
      
      // Store the real company data directly
      localStorage.setItem('adminCompanies', JSON.stringify(realCompanyData));
      
      // Use the real company data
      console.log("Setting real company data:", realCompanyData);
      setCompanies(realCompanyData);
    } catch (error) {
      console.error("Error loading companies:", error);
      setCompanies([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Load companies with the direct method that sets the real data
    loadCompanies();
    
    // Listen for company activity events
    window.addEventListener('bidPlaced', handleCompanyActivity);
    window.addEventListener('plasticPurchased', handleCompanyActivity);
    window.addEventListener('companyTransactionUpdated', handleCompanyActivity);
    
    return () => {
      window.removeEventListener('bidPlaced', handleCompanyActivity);
      window.removeEventListener('plasticPurchased', handleCompanyActivity);
      window.removeEventListener('companyTransactionUpdated', handleCompanyActivity);
    };
  }, []);
  
  // Handle company activity events
  const handleCompanyActivity = (event) => {
    console.log("Company activity detected in ManageCompanies:", event);
    // Reload company data to reflect changes
    loadCompanies();
    
    // Show toast notification based on event type
    if (event.type === 'bidPlaced' && event.detail?.company) {
      toast({
        title: "New Bid Placed",
        description: `${event.detail.company} has placed a new bid.`,
      });
    } else if (event.type === 'plasticPurchased' && event.detail?.company) {
      toast({
        title: "Plastic Purchased",
        description: `${event.detail.company} has purchased plastic waste.`,
      });
    }
  };

  const toggleCompanyStatus = (companyId) => {
    const updatedCompanies = companies.map(company => {
      if (company.id === companyId) {
        const newStatus = company.status === "Verified" ? "Pending" : "Verified";
        return { ...company, status: newStatus };
      }
      return company;
    });
    
    setCompanies(updatedCompanies);
    localStorage.setItem('adminCompanies', JSON.stringify(updatedCompanies));
    
    const companyToUpdate = companies.find(company => company.id === companyId);
    if (companyToUpdate) {
      const newStatus = companyToUpdate.status === "Verified" ? "Pending" : "Verified";
      toast({
        title: `Company ${newStatus}`,
        description: `${companyToUpdate.name} status changed to ${newStatus.toLowerCase()}.`,
      });
    }
  };

  return (
    <DashboardLayout title="Manage Companies" userType="admin">
      <Card>
        <CardHeader>
          <CardTitle>Company Management</CardTitle>
          <CardDescription>View and manage registered recycling companies</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          ) : companies.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No companies found. Companies will appear here once they register.</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Company Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Purchased Plastic</TableHead>
                  <TableHead>Total Transactions</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {companies.map(company => (
                  <TableRow key={company.id}>
                    <TableCell className="font-medium">{company.name}</TableCell>
                    <TableCell>{company.email}</TableCell>
                    <TableCell>
                      <Badge 
                        className={company.status === "Verified" ? 
                          "bg-green-100 text-green-800 hover:bg-green-100" : 
                          "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"}
                      >
                        {company.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{company.purchasedPlastic}</TableCell>
                    <TableCell>{company.totalTransactions}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">View</Button>
                        <Button 
                          variant={company.status === "Verified" ? "outline" : "default"} 
                          size="sm"
                          onClick={() => toggleCompanyStatus(company.id)}
                        >
                          {company.status === "Verified" ? "Unverify" : "Verify"}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
};

export default ManageCompanies;
