import { useState, useEffect } from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { FolderOpen, Image, FileCheck, ArrowDown } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ReviewUploads = () => {
  const { toast } = useToast();
  const [uploads, setUploads] = useState([]);
  const [loading, setLoading] = useState(true);

  // Load uploads from localStorage
  useEffect(() => {
    const loadUploads = () => {
      setLoading(true);
      try {
        const storedUploads = localStorage.getItem('adminUploads');
        if (storedUploads) {
          setUploads(JSON.parse(storedUploads));
        }
      } catch (error) {
        console.error("Error loading uploads:", error);
      } finally {
        setLoading(false);
      }
    };
    
    loadUploads();
    
    // Listen for upload events
    window.addEventListener('plasticUploaded', loadUploads);
    
    return () => {
      window.removeEventListener('plasticUploaded', loadUploads);
    };
  }, []);

  const handleApprove = (uploadId) => {
    const updatedUploads = uploads.map(upload => 
      upload.id === uploadId 
        ? { ...upload, status: 'Approved' } 
        : upload
    );
    
    setUploads(updatedUploads);
    localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    
    // Also update user uploads
    const storedUserUploads = localStorage.getItem('userUploads');
    if (storedUserUploads) {
      const userUploads = JSON.parse(storedUserUploads);
      const updatedUserUploads = userUploads.map(upload => 
        upload.id === uploadId 
          ? { ...upload, status: 'Approved' } 
          : upload
      );
      localStorage.setItem('userUploads', JSON.stringify(updatedUserUploads));
    }
    
    toast({
      title: "Upload approved",
      description: "The plastic upload has been approved.",
    });
  };

  const handleCollect = (uploadId) => {
    console.log("Collecting plastic with ID:", uploadId);
    
    const updatedUploads = uploads.map(upload => 
      upload.id === uploadId 
        ? { ...upload, status: 'Collected Awaiting Bid', collectedDate: new Date().toISOString() } 
        : upload
    );
    
    setUploads(updatedUploads);
    localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    
    // Also update user uploads
    const storedUserUploads = localStorage.getItem('userUploads');
    if (storedUserUploads) {
      const userUploads = JSON.parse(storedUserUploads);
      const updatedUserUploads = userUploads.map(upload => 
        upload.id === uploadId 
          ? { ...upload, status: 'Collected Awaiting Bid', collectedDate: new Date().toISOString() } 
          : upload
      );
      localStorage.setItem('userUploads', JSON.stringify(updatedUserUploads));
    }

    // Make this item available for bidding in company dashboard
    const storedCompanyPlastics = localStorage.getItem('availablePlastics');
    let companyPlastics = storedCompanyPlastics ? JSON.parse(storedCompanyPlastics) : [];
    
    // Find the collected item
    const collectedItem = uploads.find(upload => upload.id === uploadId);
    if (collectedItem) {
      console.log("Found collected item:", collectedItem);
      
      // Check if this plastic is already in the available plastics
      const plasticExists = companyPlastics.some(plastic => plastic.id === uploadId);
      
      if (!plasticExists) {
        const newPlasticItem = {
          id: collectedItem.id,
          type: collectedItem.type,
          quantity: `${collectedItem.quantity} ${collectedItem.unit}`,
          location: collectedItem.location,
          user: collectedItem.user || "Anonymous",
          status: 'Available',
          date: collectedItem.date,
          highestBid: 'No bids yet',
          highestBidAmount: 0,
          yourBid: null,
          yourBidAmount: null,
          images: collectedItem.imageUrls || [],
          description: collectedItem.description || ''
        };
        
        companyPlastics.push(newPlasticItem);
        console.log("Added to available plastics:", newPlasticItem);
        
        localStorage.setItem('availablePlastics', JSON.stringify(companyPlastics));
      }
    }
    
    // Dispatch an event to notify other components of the change
    console.log("Dispatching plasticCollected event");
    window.dispatchEvent(new CustomEvent('plasticCollected', { detail: { id: uploadId } }));
    
    toast({
      title: "Plastic collected",
      description: "The plastic has been collected and is now available for bidding.",
    });
  };

  const handleAcceptBid = (uploadId, bidId) => {
    const updatedUploads = uploads.map(upload => {
      if (upload.id === uploadId) {
        const updatedBids = upload.bids.map(bid => 
          bid.id === bidId 
            ? { ...bid, status: 'Accepted' } 
            : { ...bid, status: 'Rejected' }
        );
        return { ...upload, status: 'Bid Accepted', bids: updatedBids };
      }
      return upload;
    });
    
    setUploads(updatedUploads);
    localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    
    // Also update user uploads
    const storedUserUploads = localStorage.getItem('userUploads');
    if (storedUserUploads) {
      const userUploads = JSON.parse(storedUserUploads);
      const updatedUserUploads = userUploads.map(upload => 
        upload.id === uploadId 
          ? { ...upload, status: 'Bid Accepted' } 
          : upload
      );
      localStorage.setItem('userUploads', JSON.stringify(updatedUserUploads));
    }

    // Update company plastics
    const storedCompanyPlastics = localStorage.getItem('availablePlastics');
    if (storedCompanyPlastics) {
      const companyPlastics = JSON.parse(storedCompanyPlastics);
      const updatedCompanyPlastics = companyPlastics.map(plastic => 
        plastic.id === uploadId 
          ? { ...plastic, status: 'Bid Accepted' } 
          : plastic
      );
      localStorage.setItem('availablePlastics', JSON.stringify(updatedCompanyPlastics));
    }

    // Add to company orders
    const upload = uploads.find(u => u.id === uploadId);
    const acceptedBid = upload?.bids?.find(b => b.id === bidId);
    
    if (upload && acceptedBid) {
      const storedOrders = localStorage.getItem('companyOrders');
      const orders = storedOrders ? JSON.parse(storedOrders) : [];
      
      orders.push({
        id: uploadId,
        type: upload.type,
        quantity: `${upload.quantity} ${upload.unit}`,
        user: upload.user || 'Anonymous',
        date: new Date().toISOString().split('T')[0],
        amount: `$${acceptedBid.amount}`,
        bidAmount: acceptedBid.amount,
        status: 'Payment Pending',
        images: upload.imageUrls || []
      });
      
      localStorage.setItem('companyOrders', JSON.stringify(orders));
    }
    
    toast({
      title: "Bid accepted",
      description: "The bid has been accepted. Waiting for payment proof from the company.",
    });
  };

  const handleVerifyPayment = (uploadId) => {
    // Find the upload and the company that won the bid
    const upload = uploads.find(u => u.id === uploadId);
    const winningBid = upload?.bids?.find(b => b.status === 'Accepted');
    
    const updatedUploads = uploads.map(upload => {
      if (upload.id === uploadId) {
        return { 
          ...upload, 
          status: 'Sold', 
          paymentStatus: 'Verified',
        };
      }
      return upload;
    });
    
    setUploads(updatedUploads);
    localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    
    // Also update user uploads and add points
    const storedUserUploads = localStorage.getItem('userUploads');
    if (storedUserUploads) {
      const userUploads = JSON.parse(storedUserUploads);
      const updatedUserUploads = userUploads.map(upload => 
        upload.id === uploadId 
          ? { ...upload, status: 'Sold', paymentStatus: 'Verified' } 
          : upload
      );
      localStorage.setItem('userUploads', JSON.stringify(updatedUserUploads));
      
      // Add points for the user - 10 points per kg
      const soldUpload = updatedUploads.find(u => u.id === uploadId);
      if (soldUpload) {
        const pointsToAdd = soldUpload.unit === 'kg' ? Math.round(parseFloat(soldUpload.quantity) * 10) : 10;
        const currentPoints = parseInt(localStorage.getItem('userPoints') || '0');
        localStorage.setItem('userPoints', (currentPoints + pointsToAdd).toString());
      }
    }

    // Update company orders
    const storedOrders = localStorage.getItem('companyOrders');
    if (storedOrders) {
      const orders = JSON.parse(storedOrders);
      const updatedOrders = orders.map(order => 
        order.id === uploadId 
          ? { ...order, status: 'Completed' } 
          : order
      );
      localStorage.setItem('companyOrders', JSON.stringify(updatedOrders));
    }

    // Remove from available plastics
    const storedCompanyPlastics = localStorage.getItem('availablePlastics');
    if (storedCompanyPlastics) {
      const companyPlastics = JSON.parse(storedCompanyPlastics);
      const updatedCompanyPlastics = companyPlastics.filter(plastic => plastic.id !== uploadId);
      localStorage.setItem('availablePlastics', JSON.stringify(updatedCompanyPlastics));
    }
    
    toast({
      title: "Payment verified",
      description: "The payment has been verified and the plastic has been sold. User has received points.",
    });
  };
  
  // Simulate a company adding a bid
  const simulateAddBid = (uploadId) => {
    const updatedUploads = uploads.map(upload => {
      if (upload.id === uploadId) {
        const existingBids = upload.bids || [];
        const newBid = {
          id: Date.now().toString(),
          company: 'EcoRecycle Inc.',
          amount: Math.round(Math.random() * 100) + 50,
          status: 'Pending'
        };
        return { 
          ...upload, 
          bids: [...existingBids, newBid]
        };
      }
      return upload;
    });
    
    setUploads(updatedUploads);
    localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    
    toast({
      title: "New bid received",
      description: "A company has placed a bid on this plastic waste.",
    });
  };
  
  // Simulate adding payment proof
  const simulatePaymentProof = (uploadId) => {
    const updatedUploads = uploads.map(upload => {
      if (upload.id === uploadId) {
        return { 
          ...upload, 
          paymentProof: '/lovable-uploads/fd78de08-d412-4f18-af66-2ea68b978016.png',
          paymentStatus: 'Pending Verification'
        };
      }
      return upload;
    });
    
    setUploads(updatedUploads);
    localStorage.setItem('adminUploads', JSON.stringify(updatedUploads));
    
    toast({
      title: "Payment proof received",
      description: "The company has submitted payment proof for verification.",
    });
  };

  return (
    <DashboardLayout title="Review Uploads" userType="admin">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-ecoplastix-green" />
            Plastic Upload Reviews
          </CardTitle>
          <CardDescription>
            Review and approve plastic waste uploads and bids
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
            </div>
          ) : uploads.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 mb-4">No uploads to review yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left border-b">
                    <th className="pb-2 font-medium">Type</th>
                    <th className="pb-2 font-medium">Quantity</th>
                    <th className="pb-2 font-medium">Location</th>
                    <th className="pb-2 font-medium">User</th>
                    <th className="pb-2 font-medium">Status</th>
                    <th className="pb-2 font-medium">Date</th>
                    <th className="pb-2 font-medium">Bids</th>
                    <th className="pb-2 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {uploads.map(upload => (
                    <tr key={upload.id} className="border-b">
                      <td className="py-3">{upload.type}</td>
                      <td>{upload.quantity} {upload.unit}</td>
                      <td>{upload.location}</td>
                      <td>{upload.user || 'Anonymous'}</td>
                      <td>
                        <Badge className={
                          upload.status === 'Approved' ? 'bg-green-100 text-green-800 hover:bg-green-100' : 
                          upload.status === 'Collected Awaiting Bid' ? 'bg-blue-100 text-blue-800 hover:bg-blue-100' :
                          upload.status === 'Bid Accepted' ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100' :
                          upload.status === 'Sold' ? 'bg-purple-100 text-purple-800 hover:bg-purple-100' :
                          'bg-orange-100 text-orange-800 hover:bg-orange-100'
                        }>
                          {upload.status || 'Collection Pending'}
                        </Badge>
                      </td>
                      <td>{upload.date}</td>
                      <td>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              {upload.bids?.length || 0} Bids
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-md">
                            <DialogHeader>
                              <DialogTitle>Bids for {upload.type}</DialogTitle>
                              <DialogDescription>
                                Select a bid to accept for this plastic upload
                              </DialogDescription>
                            </DialogHeader>
                            <div className="mt-4">
                              {!upload.bids || upload.bids.length === 0 ? (
                                <div className="text-center py-4">
                                  <p className="text-gray-500 mb-3">No bids received yet</p>
                                  {upload.status === 'Collected Awaiting Bid' && (
                                    <Button 
                                      size="sm" 
                                      onClick={() => simulateAddBid(upload.id)}
                                      className="bg-ecoplastix-blue hover:bg-ecoplastix-blue-dark"
                                    >
                                      Simulate Bid (Demo)
                                    </Button>
                                  )}
                                </div>
                              ) : (
                                <table className="w-full">
                                  <thead>
                                    <tr className="text-left border-b">
                                      <th className="pb-2 font-medium">Company</th>
                                      <th className="pb-2 font-medium">Amount ($)</th>
                                      <th className="pb-2 font-medium">Status</th>
                                      <th className="pb-2 font-medium">Action</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {upload.bids.map(bid => (
                                      <tr key={bid.id} className="border-b">
                                        <td className="py-2">{bid.company}</td>
                                        <td>${bid.amount}</td>
                                        <td>
                                          <Badge className={
                                            bid.status === 'Accepted' ? 'bg-green-100 text-green-800' : 
                                            bid.status === 'Rejected' ? 'bg-red-100 text-red-800' :
                                            'bg-yellow-100 text-yellow-800'
                                          }>
                                            {bid.status}
                                          </Badge>
                                        </td>
                                        <td>
                                          {bid.status === 'Pending' && upload.status !== 'Sold' && upload.status !== 'Bid Accepted' && (
                                            <Button 
                                              size="sm" 
                                              className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                                              onClick={() => handleAcceptBid(upload.id, bid.id)}
                                            >
                                              Accept
                                            </Button>
                                          )}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              )}
                            </div>
                          </DialogContent>
                        </Dialog>
                      </td>
                      <td>
                        <div className="flex gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" className="flex items-center gap-1">
                                <Image className="h-4 w-4" /> Images
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>{upload.type} Images</DialogTitle>
                                <DialogDescription>
                                  Images of the plastic waste uploaded by {upload.user || 'Anonymous'}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="grid grid-cols-2 gap-4 mt-4">
                                {upload.imageUrls && upload.imageUrls.map((img, idx) => (
                                  <div key={idx} className="border rounded-md overflow-hidden">
                                    <img src={img} alt={`Plastic upload ${idx+1}`} className="w-full h-48 object-cover" />
                                  </div>
                                ))}
                                {!upload.imageUrls && upload.imageNames && (
                                  <div className="border rounded-md overflow-hidden p-4 text-center">
                                    <p>{upload.imageNames.join(', ')}</p>
                                  </div>
                                )}
                              </div>
                            </DialogContent>
                          </Dialog>
                          
                          {upload.status === 'Collection Pending' && (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-green-600 hover:text-green-700"
                              onClick={() => handleApprove(upload.id)}
                            >
                              Approve
                            </Button>
                          )}
                          
                          {upload.status === 'Approved' && (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-blue-600 hover:text-blue-700 flex items-center gap-1"
                              onClick={() => handleCollect(upload.id)}
                            >
                              <ArrowDown className="h-4 w-4" /> Collect
                            </Button>
                          )}
                          
                          {upload.status === 'Bid Accepted' && !upload.paymentProof && (
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-blue-600 hover:text-blue-700"
                              onClick={() => simulatePaymentProof(upload.id)}
                            >
                              Simulate Payment Proof (Demo)
                            </Button>
                          )}
                          
                          {upload.paymentProof && upload.paymentStatus === 'Pending Verification' && (
                            <>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="flex items-center gap-1 bg-blue-100 text-blue-800 hover:bg-blue-200"
                                  >
                                    <FileCheck className="h-4 w-4" /> Payment Proof
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Payment Proof</DialogTitle>
                                    <DialogDescription>
                                      Verify the payment proof submitted by the company
                                    </DialogDescription>
                                  </DialogHeader>
                                  <div className="mt-4">
                                    <div className="border rounded-md overflow-hidden">
                                      <img src={upload.paymentProof} alt="Payment proof" className="w-full h-48 object-contain" />
                                    </div>
                                    <div className="mt-4 flex justify-end">
                                      <Button 
                                        onClick={() => handleVerifyPayment(upload.id)}
                                        className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark"
                                      >
                                        Verify Payment
                                      </Button>
                                    </div>
                                  </div>
                                </DialogContent>
                              </Dialog>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
};

export default ReviewUploads;
