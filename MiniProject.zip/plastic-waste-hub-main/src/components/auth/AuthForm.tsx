import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { EyeIcon, EyeOffIcon } from "lucide-react";

type UserRole = 'user' | 'company' | 'admin';

interface AuthFormProps {
  allowSignup?: boolean;
  allowRoleSelection?: boolean;
  defaultRole?: UserRole;
}

const AuthForm = ({ 
  allowSignup = true, 
  allowRoleSelection = true,
  defaultRole = 'user'
}: AuthFormProps) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [role, setRole] = useState<UserRole>(defaultRole);
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState("");
  const { toast } = useToast();
  const navigate = useNavigate();

  // Load registered users from localStorage
  useEffect(() => {
    if (!localStorage.getItem('registeredUsers')) {
      localStorage.setItem('registeredUsers', JSON.stringify([]));
    }
    
    // Set admin user
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    if (!registeredUsers.find((user: any) => user.role === 'admin')) {
      registeredUsers.push({
        email: 'admin@ecoplastix.com',
        password: 'admin123',
        name: 'Admin',
        role: 'admin'
      });
      localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
    }
  }, []);

  const validatePassword = (pass: string): boolean => {
    if (pass.length < 8) {
      setPasswordError("Password must be at least 8 characters long");
      return false;
    }
    
    // Check for complexity requirements
    const hasUppercase = /[A-Z]/.test(pass);
    const hasLowercase = /[a-z]/.test(pass);
    const hasNumbers = /\d/.test(pass);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(pass);
    
    if (!(hasUppercase && hasLowercase && hasNumbers)) {
      setPasswordError("Password must contain uppercase, lowercase, and numbers");
      return false;
    }
    
    setPasswordError("");
    return true;
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: "Error",
        description: "Please enter both email and password",
        variant: "destructive"
      });
      return;
    }
    
    // Check if user exists in localStorage
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const user = registeredUsers.find((u: any) => 
      u.email.toLowerCase() === email.toLowerCase() && u.password === password && u.role === role
    );
    
    if (user) {
      // Store current user
      localStorage.setItem('currentUser', user.name);
      localStorage.setItem('currentUserRole', user.role);
      
      // Redirect based on role
      if (user.role === 'user') {
        navigate('/user-dashboard');
      } else if (user.role === 'company') {
        navigate('/company-dashboard');
      } else if (user.role === 'admin') {
        navigate('/admin-dashboard');
      }
    } else {
      toast({
        title: "Login Failed",
        description: "Invalid email or password. Please check your credentials or sign up.",
        variant: "destructive"
      });
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password || !name) {
      toast({
        title: "Error",
        description: "Please fill out all fields",
        variant: "destructive"
      });
      return;
    }
    
    // Validate password
    if (!validatePassword(password)) {
      toast({
        title: "Weak Password",
        description: passwordError,
        variant: "destructive"
      });
      return;
    }
    
    // Check if user already exists
    const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    if (registeredUsers.some((u: any) => u.email.toLowerCase() === email.toLowerCase())) {
      toast({
        title: "Error",
        description: "An account with this email already exists",
        variant: "destructive"
      });
      return;
    }
    
    // Register new user
    const newUser = { email, password, name, role };
    registeredUsers.push(newUser);
    localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
    
    // Store current user
    localStorage.setItem('currentUser', name);
    localStorage.setItem('currentUserRole', role);
    
    toast({
      title: "Account Created",
      description: "Your account has been created successfully",
    });
    
    // Redirect based on role
    if (role === 'user') {
      navigate('/user-dashboard');
    } else if (role === 'company') {
      navigate('/company-dashboard');
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <Card className="w-full max-w-md mx-auto shadow-lg border-t-4 border-t-ecoplastix-green">
      <Tabs defaultValue="login">
        <CardHeader className="space-y-1 pb-6">
          <div className="flex items-center justify-between mb-6">
            <CardTitle className="text-2xl font-bold">
              <span className="text-ecoplastix-green-light">Eco</span>
              <span className="text-ecoplastix-green-dark">Plastix</span>
            </CardTitle>
            {allowSignup && (
              <TabsList className="grid w-full grid-cols-2 ml-4">
                <TabsTrigger value="login" className="px-6">Login</TabsTrigger>
                <TabsTrigger value="signup" className="px-6">Sign Up</TabsTrigger>
              </TabsList>
            )}
          </div>
          <CardDescription>
            Manage your plastic waste efficiently with our platform
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <TabsContent value="login">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? (
                      <EyeOffIcon className="h-4 w-4" />
                    ) : (
                      <EyeIcon className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
              
              {allowRoleSelection && (
                <div className="space-y-2">
                  <Label htmlFor="role">I am a</Label>
                  <Select 
                    value={role} 
                    onValueChange={(value) => setRole(value as UserRole)}
                  >
                    <SelectTrigger id="role">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">User</SelectItem>
                      <SelectItem value="company">Company</SelectItem>
                      {/* Only show admin in login form */}
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button type="submit" className="w-full bg-ecoplastix-green-dark hover:bg-ecoplastix-green-dark/90 text-white">
                Login
              </Button>
            </form>
          </TabsContent>

          {allowSignup && (
            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="emailSignup">Email</Label>
                  <Input
                    id="emailSignup"
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="passwordSignup">
                    Password
                    <span className="ml-1 text-xs text-gray-500">
                      (min 8 chars with uppercase, lowercase, number)
                    </span>
                  </Label>
                  <div className="relative">
                    <Input
                      id="passwordSignup"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        validatePassword(e.target.value);
                      }}
                      required
                      className={passwordError ? "border-red-300" : ""}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={togglePasswordVisibility}
                    >
                      {showPassword ? (
                        <EyeOffIcon className="h-4 w-4" />
                      ) : (
                        <EyeIcon className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  {passwordError && (
                    <p className="text-sm text-red-500">{passwordError}</p>
                  )}
                </div>
                
                {allowRoleSelection && (
                  <div className="space-y-2">
                    <Label htmlFor="roleSignup">I am a</Label>
                    <Select 
                      value={role} 
                      onValueChange={(value) => setRole(value as UserRole)}
                    >
                      <SelectTrigger id="roleSignup">
                        <SelectValue placeholder="Select your role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="company">Company</SelectItem>
                        {/* Don't show admin in signup form */}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <Button type="submit" className="w-full bg-ecoplastix-green-light hover:bg-ecoplastix-green-light/90 text-white">
                  Create Account
                </Button>
              </form>
            </TabsContent>
          )}
        </CardContent>

        <CardFooter className="flex justify-center border-t pt-4">
          <p className="text-sm text-gray-500 flex items-center">
            <span className="text-ecoplastix-green-light mr-1">Eco</span>
            <span className="text-ecoplastix-green-dark mr-1">Plastix</span> 
            - Connecting waste to resources
          </p>
        </CardFooter>
      </Tabs>
    </Card>
  );
};

export default AuthForm;
