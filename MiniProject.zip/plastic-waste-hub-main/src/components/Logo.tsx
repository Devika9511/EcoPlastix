
import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showText = true }) => {
  const sizeClasses = {
    sm: 'h-8 w-auto',
    md: 'h-12 w-auto',
    lg: 'h-16 w-auto'
  };

  return (
    <div className={`flex items-center ${className}`}>
      <img 
        src="/lovable-uploads/fd78de08-d412-4f18-af66-2ea68b978016.png" 
        alt="EcoPlastix Logo" 
        className={`${sizeClasses[size]} mr-2`}
      />
      {showText && (
        <div className={`font-bold ${size === 'lg' ? 'text-2xl' : size === 'md' ? 'text-xl' : 'text-lg'}`}>
          <span className="text-ecoplastix-green-light">Eco</span>
          <span className="text-ecoplastix-green-dark">Plastix</span>
        </div>
      )}
    </div>
  );
};

export default Logo;
