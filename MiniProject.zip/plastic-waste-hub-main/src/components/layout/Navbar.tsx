
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import Logo from "@/components/Logo";
import { MenuIcon } from "lucide-react";
import { useState } from "react";

interface NavbarProps {
  includeAuth?: boolean;
}

const Navbar = ({ includeAuth = true }: NavbarProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo and Desktop Navigation */}
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <Logo size="md" />
            </Link>
            <div className="hidden md:ml-10 md:flex md:space-x-8">
              <Link to="/" className="text-gray-700 hover:text-ecoplastix-green px-3 py-2 text-sm font-medium">
                Home
              </Link>
              <Link to="/about" className="text-gray-700 hover:text-ecoplastix-green px-3 py-2 text-sm font-medium">
                About
              </Link>
              <Link to="/contact" className="text-gray-700 hover:text-ecoplastix-green px-3 py-2 text-sm font-medium">
                Contact Us
              </Link>
              <Link to="/user-dashboard/rewards" className="text-gray-700 hover:text-ecoplastix-green px-3 py-2 text-sm font-medium">
                Rewards
              </Link>
            </div>
          </div>
          
          {/* Auth Buttons and Mobile Menu Button */}
          <div className="flex items-center">
            {includeAuth && (
              <div className="hidden md:flex items-center space-x-4">
                <Link to="/login" className="text-gray-700 hover:text-ecoplastix-green">
                  Login
                </Link>
                <Link to="/signup">
                  <Button className="bg-ecoplastix-green-dark hover:bg-ecoplastix-green-dark/90 text-white">
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}
            
            {!includeAuth && (
              <div className="hidden md:flex items-center space-x-4">
                <Link to="/user-dashboard">
                  <Button className="bg-ecoplastix-green hover:bg-ecoplastix-green-dark/90 text-white">
                    Dashboard
                  </Button>
                </Link>
                <Link to="/">
                  <Button variant="outline">
                    Logout
                  </Button>
                </Link>
              </div>
            )}
            
            <div className="flex md:hidden ml-auto">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-ecoplastix-green hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-ecoplastix-green"
              >
                <span className="sr-only">Open main menu</span>
                <MenuIcon className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-200">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-ecoplastix-green hover:bg-gray-100">
              Home
            </Link>
            <Link to="/about" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-ecoplastix-green hover:bg-gray-100">
              About
            </Link>
            <Link to="/contact" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-ecoplastix-green hover:bg-gray-100">
              Contact Us
            </Link>
            <Link to="/user-dashboard/rewards" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-ecoplastix-green hover:bg-gray-100">
              Rewards
            </Link>
            
            {includeAuth && (
              <div className="pt-4 border-t border-gray-200">
                <Link to="/login" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-ecoplastix-green hover:bg-gray-100">
                  Login
                </Link>
                <Link to="/signup" className="block px-3 py-2 rounded-md text-base font-medium text-white bg-ecoplastix-green-dark hover:bg-ecoplastix-green-dark/90 text-center mt-2">
                  Sign Up
                </Link>
              </div>
            )}
            
            {!includeAuth && (
              <div className="pt-4 border-t border-gray-200">
                <Link to="/user-dashboard" className="block px-3 py-2 rounded-md text-base font-medium text-white bg-ecoplastix-green hover:bg-ecoplastix-green-dark/90 text-center">
                  Dashboard
                </Link>
                <Link to="/" className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 border border-gray-300 hover:bg-gray-100 text-center mt-2">
                  Logout
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
