
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { 
  Home,
  User,
  Building,
  LogOut,
  Menu,
  X,
  Upload,
  Folder,
  FolderOpen
} from "lucide-react";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title: string;
  userType: 'user' | 'company' | 'admin';
}

const DashboardLayout = ({ children, title, userType }: DashboardLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const navigate = useNavigate();
  
  const handleLogout = () => {
    // In a real app, this would clear auth tokens/cookies
    navigate('/');
  };
  
  // Define navigation items based on user type
  const getNavItems = () => {
    switch (userType) {
      case 'user':
        return [
          { icon: Home, label: 'Dashboard', path: '/user-dashboard' },
          { icon: Upload, label: 'Upload Plastic', path: '/user-dashboard/upload' },
          { icon: Folder, label: 'My Uploads', path: '/user-dashboard/my-uploads' },
          { icon: User, label: 'Profile', path: '/user-dashboard/profile' },
        ];
      case 'company':
        return [
          { icon: Home, label: 'Dashboard', path: '/company-dashboard' },
          { icon: FolderOpen, label: 'Available Plastics', path: '/company-dashboard/available-plastics' },
          { icon: Folder, label: 'My Orders', path: '/company-dashboard/my-orders' },
          { icon: Building, label: 'Company Profile', path: '/company-dashboard/profile' },
        ];
      case 'admin':
        return [
          { icon: Home, label: 'Dashboard', path: '/admin-dashboard' },
          { icon: User, label: 'Manage Users', path: '/admin-dashboard/users' },
          { icon: Building, label: 'Manage Companies', path: '/admin-dashboard/companies' },
          { icon: FolderOpen, label: 'Review Uploads', path: '/admin-dashboard/uploads' },
        ];
      default:
        return [];
    }
  };

  const navItems = getNavItems();
  
  // Determine user role icon
  const getUserIcon = () => {
    switch (userType) {
      case 'user': return <User className="h-5 w-5" />;
      case 'company': return <Building className="h-5 w-5" />;
      case 'admin': return <User className="h-5 w-5" />;
      default: return <User className="h-5 w-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div 
        className={`
          ${sidebarOpen ? 'translate-x-0 w-64' : 'translate-x-[-100%] w-0'} 
          fixed lg:static top-0 left-0 z-40 h-full 
          bg-white shadow-lg transition-all duration-300 ease-in-out
          lg:translate-x-0 ${sidebarOpen ? 'lg:w-64' : 'lg:w-20'}
        `}
      >
        <div className="h-full flex flex-col">
          <div className={`h-16 px-4 flex items-center border-b ${!sidebarOpen && 'lg:justify-center'}`}>
            <span className={`text-xl font-bold text-ecoplastix-green ${!sidebarOpen && 'lg:hidden'}`}>
              EcoPlastix
            </span>
            <button 
              className="ml-auto lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="flex-grow overflow-y-auto">
            <div className="py-4">
              {navItems.map((item, index) => (
                <button
                  key={index}
                  className="w-full flex items-center px-4 py-3 text-gray-700 hover:bg-gray-100 hover:text-ecoplastix-green"
                  onClick={() => navigate(item.path)}
                >
                  <item.icon className="h-5 w-5" />
                  <span className={`ml-4 ${!sidebarOpen && 'lg:hidden'}`}>{item.label}</span>
                </button>
              ))}
            </div>
          </div>
          
          <div className="p-4 border-t">
            <button
              className="w-full flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5" />
              <span className={`ml-4 ${!sidebarOpen && 'lg:hidden'}`}>Logout</span>
            </button>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Top header */}
        <header className="h-16 bg-white shadow-sm flex items-center px-4">
          <button 
            className="mr-4 lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </button>
          <button
            className="mr-4 hidden lg:block"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            <Menu className="h-5 w-5" />
          </button>
          
          <h1 className="text-xl font-medium">{title}</h1>
          
          <div className="ml-auto flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-ecoplastix-green-light flex items-center justify-center">
              {getUserIcon()}
            </div>
            <span className="text-sm font-medium">
              {userType.charAt(0).toUpperCase() + userType.slice(1)} Account
            </span>
          </div>
        </header>
        
        {/* Page content */}
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="mx-auto max-w-7xl">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
